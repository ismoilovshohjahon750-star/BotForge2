
# CloudBot Auto-injected Global Error Handler
async def _cloudbot_error_handler(update, context):
    if not context.error:
        return
    err_str = str(context.error)
    err_type = type(context.error).__name__
    transient = ('httpx.ReadError', 'httpx.ConnectError', 'httpx.RemoteProtocolError', 'httpx.ReadTimeout', 'httpx.ConnectTimeout', 'httpx.TimeoutException', 'ReadError', 'ConnectError', 'RemoteProtocolError', 'ReadTimeout', 'ConnectTimeout', 'TimeoutException', 'TimedOut', 'NetworkError', 'RetryAfter')
    if any(t in err_str or t in err_type for t in transient):
        return
    import logging
    logging.warning(f"Bot handler notice: {context.error}")

"""
ArdoChat Bot — asosiy menyu, profil, tarif, balans, ulash va sozlamalar
uchun handlerlar. Har bir o'zgarish darhol SQLite bazasiga yoziladi
(storage.save / storage.add_* orqali) — hech narsa faqat xotirada
qolib ketmaydi.
"""
import asyncio
import logging
import re

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

import texts
import keyboards
import payments
import profile_clock
from config import TARIFFS, MIN_TOPUP_SOM, ADMIN_ID
from storage import storage

logger = logging.getLogger(__name__)

WAITING_AMOUNT = "waiting_amount"
WAITING_AMOUNT_METHOD = "waiting_amount_method"
WAITING_SETTING_INPUT = "waiting_setting_input"
WAITING_SOAT_PHONE = "waiting_soat_phone"
WAITING_SOAT_CODE = "waiting_soat_code"
WAITING_SOAT_PASSWORD = "waiting_soat_password"
# Login (telefon -> kod -> [parol]) tugagach QAYSI funksiya yoqilishi kerak:
# "soat" | "online" | "spy" — shu login orqali uchoviga ham bitta sessiya
# yetarli, lekin foydalanuvchi qaysi tugmadan kirgan bo'lsa, o'sha yoqiladi.
WAITING_SOAT_PURPOSE = "waiting_soat_purpose"

# --- admin panel uchun kutilayotgan matn kirishlari ---
WAITING_ADMIN_USER_SEARCH = "waiting_admin_user_search"
WAITING_ADMIN_ADDBAL_USER = "waiting_admin_addbal_user"
WAITING_ADMIN_GIVEPRO_USER = "waiting_admin_givepro_user"
WAITING_ADMIN_GIVEPRO_DAYS = "waiting_admin_givepro_days"
WAITING_EMOJI_CHAR = "waiting_emoji_char"
WAITING_EMOJI_ID = "waiting_emoji_id"
WAITING_CONTACT_NOTE = "waiting_contact_note"
WAITING_KEYWORD_ADD = "waiting_keyword_add"
ADMIN_BROADCAST_PENDING_TEXT = "admin_broadcast_pending_text"


# ---------------------------------------------------------------- /start ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_tg = update.effective_user
    user = storage.get(user_tg.id, user_tg.first_name)

    if user.is_banned:
        await update.message.reply_text(texts.banned_notice_text())
        return

    # Referal orqali kirgan bo'lsa: /start ref_123456
    if context.args:
        arg = context.args[0]
        if arg.startswith("ref_"):
            try:
                referrer_id = int(arg.split("_", 1)[1])
                added = storage.add_referral(referrer_id, user_tg.id)
                if added:
                    try:
                        await context.bot.send_message(
                            chat_id=referrer_id,
                            text="\U0001f465 Sizning taklif havolangiz orqali yangi foydalanuvchi qo'shildi! \u2b50 yulduzcha berildi.",
                        )
                    except Exception:
                        pass
            except ValueError:
                pass

    await update.message.reply_text(
        texts.welcome_text(user_tg.first_name, connected=user.connected),
        reply_markup=keyboards.main_menu_kb(user.connected, is_admin=_is_admin(update)),
        parse_mode=ParseMode.HTML,
    )


# --------------------------------------------------------------- /myid ----
async def myid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"Sizning Telegram ID: <code>{update.effective_user.id}</code>",
                                     parse_mode=ParseMode.HTML)


# --------------------------------------------------------- /admin_stats ---
async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if ADMIN_ID is None or update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("Bu buyruq faqat admin uchun.")
        return
    s = storage.stats()
    lines = [
        "\U0001f4ca Statistika:",
        f"Jami foydalanuvchi: {s['total']}",
        f"Business orqali ulangan: {s['connected']}",
    ]
    for tariff, count in s['by_tariff'].items():
        lines.append(f"  {TARIFFS.get(tariff, {}).get('title', tariff)}: {count}")
    await update.message.reply_text("\n".join(lines))


# ---------------------------------------------------------- /credit (admin) --
async def admin_credit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/credit <user_id> <amount> — adminning qo'lda balans qo'shishi (real)."""
    if ADMIN_ID is None or update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("Bu buyruq faqat admin uchun.")
        return
    if len(context.args) != 2 or not all(a.lstrip("-").isdigit() for a in context.args):
        await update.message.reply_text("Format: /credit <user_id> <summa>")
        return
    target_id, amount = int(context.args[0]), int(context.args[1])
    storage.add_balance_som(target_id, amount)
    await update.message.reply_text(f"\u2705 {target_id} foydalanuvchiga {amount} so'm qo'shildi.")
    try:
        await context.bot.send_message(
            chat_id=target_id, text=f"\U0001f4b0 Balansingizga {amount} so'm qo'shildi."
        )
    except Exception:
        pass


# -------------------------------------------------------------- /admin ----
WAITING_BROADCAST_TEXT = "waiting_broadcast_text"


def _is_admin(update: Update) -> bool:
    return ADMIN_ID is not None and update.effective_user.id == ADMIN_ID


def _clear_admin_waiting(context: ContextTypes.DEFAULT_TYPE):
    """Admin panelning istalgan boshqa bo'limiga o'tilganda (orqaga/bekor
    qilish yoki menyudagi istalgan tugma) eski 'matn kutilmoqda' holatlari
    tozalanadi — aks holda admin masalan foydalanuvchi qidirishni bekor
    qilib boshqa buyruqqa o'tsa, keyingi yozgan xabari xato ravishda o'sha
    eski so'rov sifatida qabul qilinib qolishi mumkin edi."""
    context.user_data[WAITING_ADMIN_USER_SEARCH] = False
    context.user_data[WAITING_ADMIN_ADDBAL_USER] = None
    context.user_data[WAITING_BROADCAST_TEXT] = False
    context.user_data[ADMIN_BROADCAST_PENDING_TEXT] = None
    context.user_data[WAITING_ADMIN_GIVEPRO_USER] = None
    context.user_data[WAITING_ADMIN_GIVEPRO_DAYS] = False
    context.user_data[WAITING_EMOJI_CHAR] = False
    context.user_data[WAITING_EMOJI_ID] = None


async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/admin — admin uchun yagona boshqaruv paneli (katta versiya:
    statistika, foydalanuvchilarni boshqarish, to'lovlar, xabar yuborish,
    bloklash)."""
    if not _is_admin(update):
        await update.message.reply_text("Bu buyruq faqat admin uchun.")
        return
    _clear_admin_waiting(context)
    s = storage.stats()
    await update.message.reply_text(
        texts.admin_home_text(pending=s['pending_topups'], banned=s['banned']),
        reply_markup=keyboards.admin_menu_kb(pending=s['pending_topups'], banned=s['banned']),
        parse_mode=ParseMode.HTML,
    )


async def _show_admin_user_card(query, context, target_id: int):
    target = storage.find_existing(target_id)
    if target is None:
        await query.edit_message_text(
            texts.admin_user_not_found_text(target_id),
            reply_markup=keyboards.admin_back_kb(),
            parse_mode=ParseMode.HTML,
        )
        return
    await query.edit_message_text(
        texts.admin_user_card_text(target),
        reply_markup=keyboards.admin_user_kb(target),
        parse_mode=ParseMode.HTML,
    )


async def _admin_callback(query, context, update):
    if not _is_admin(update):
        await query.answer("Bu bo'lim faqat admin uchun.", show_alert=True)
        return
    data = query.data
    parts = data.split(":")

    if data == "admin:home":
        _clear_admin_waiting(context)
        s = storage.stats()
        await query.edit_message_text(
            texts.admin_home_text(pending=s['pending_topups'], banned=s['banned']),
            reply_markup=keyboards.admin_menu_kb(pending=s['pending_topups'], banned=s['banned']),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:stats":
        s = storage.stats()
        await query.edit_message_text(
            texts.admin_stats_text(s),
            reply_markup=keyboards.admin_back_kb(),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:report":
        r = storage.daily_report()
        await query.edit_message_text(
            texts.admin_report_text(r),
            reply_markup=keyboards.admin_back_kb(),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:logs":
        page_size = 20
        rows = storage.list_admin_logs(limit=page_size + 1, offset=0)
        has_more = len(rows) > page_size
        rows = rows[:page_size]
        await query.edit_message_text(
            texts.admin_logs_text(rows, offset=0),
            reply_markup=keyboards.admin_list_page_kb("logspage", page_size, has_more),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:pending":
        rows = storage.list_pending_topups()
        await query.edit_message_text(
            texts.admin_pending_text(rows),
            reply_markup=keyboards.admin_back_kb(),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:broadcast":
        context.user_data[WAITING_BROADCAST_TEXT] = True
        await query.edit_message_text(
            "\U0001f4e2 Barcha foydalanuvchilarga yuboriladigan xabar matnini yozing:",
            reply_markup=keyboards.admin_cancel_kb(),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:broadcast_cancel":
        context.user_data[WAITING_BROADCAST_TEXT] = False
        context.user_data[ADMIN_BROADCAST_PENDING_TEXT] = None
        s = storage.stats()
        await query.edit_message_text(
            texts.admin_home_text(pending=s['pending_topups'], banned=s['banned']),
            reply_markup=keyboards.admin_menu_kb(pending=s['pending_topups'], banned=s['banned']),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:broadcast_send":
        pending_text = context.user_data.get(ADMIN_BROADCAST_PENDING_TEXT)
        context.user_data[ADMIN_BROADCAST_PENDING_TEXT] = None
        if not pending_text:
            await query.answer("Yuboriladigan matn topilmadi, qaytadan urinib ko'ring.", show_alert=True)
            return
        user_ids = storage.all_user_ids()
        total = len(user_ids)
        await query.edit_message_text(
            texts.admin_broadcast_sending_text(0, total), parse_mode=ParseMode.HTML
        )
        sent, failed = 0, 0
        for i, uid in enumerate(user_ids, start=1):
            try:
                await context.bot.send_message(chat_id=uid, text=pending_text)
                sent += 1
            except Exception:
                failed += 1
            # Telegram flood-limitiga tegib qolmaslik uchun kichik pauza
            await asyncio.sleep(0.05)
            if i % 25 == 0 or i == total:
                try:
                    await query.edit_message_text(
                        texts.admin_broadcast_sending_text(i, total), parse_mode=ParseMode.HTML
                    )
                except Exception:
                    pass
        storage.log_admin_action("broadcast", None, f"{sent} ta yuborildi, {failed} ta xato")
        await query.edit_message_text(
            texts.admin_broadcast_result_text(sent, failed),
            reply_markup=keyboards.admin_back_kb(),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:users":
        context.user_data[WAITING_ADMIN_USER_SEARCH] = True
        await query.edit_message_text(
            "\U0001f465 Boshqarmoqchi bo'lgan foydalanuvchining Telegram ID "
            "raqamini yuboring (masalan: <code>123456789</code>).\n\n"
            "<i>ID'ni bilmasangiz, foydalanuvchi botga <code>/myid</code> "
            "yozib o'zi bilib olishi mumkin.</i>",
            reply_markup=keyboards.admin_cancel_kb(),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:banned" or parts[0:2] == ["admin", "bannedpage"]:
        offset = 0
        if parts[0:2] == ["admin", "bannedpage"] and len(parts) == 3:
            try:
                offset = int(parts[2])
            except ValueError:
                offset = 0
        page_size = 20
        users = storage.list_banned_page(limit=page_size + 1, offset=offset)
        has_more = len(users) > page_size
        users = users[:page_size]
        await query.edit_message_text(
            texts.admin_banned_list_text(users, offset=offset),
            reply_markup=keyboards.admin_list_page_kb("bannedpage", offset + page_size, has_more),
            parse_mode=ParseMode.HTML,
        )
        return

    if parts[0:2] == ["admin", "logspage"]:
        offset = 0
        if len(parts) == 3:
            try:
                offset = int(parts[2])
            except ValueError:
                offset = 0
        page_size = 20
        rows = storage.list_admin_logs(limit=page_size + 1, offset=offset)
        has_more = len(rows) > page_size
        rows = rows[:page_size]
        await query.edit_message_text(
            texts.admin_logs_text(rows, offset=offset),
            reply_markup=keyboards.admin_list_page_kb("logspage", offset + page_size, has_more),
            parse_mode=ParseMode.HTML,
        )
        return

    if data == "admin:emoji" or data.startswith("emoji:"):
        import pemoji as _pemoji
        emoji_map = storage.get_premium_emoji_map()
        if data == "admin:emoji":
            await query.edit_message_text(
                texts.admin_emoji_text(emoji_map),
                reply_markup=keyboards.admin_emoji_kb(emoji_map),
                parse_mode=ParseMode.HTML,
            )
            return
        if data == "emoji:add":
            context.user_data[WAITING_EMOJI_CHAR] = True
            context.user_data[WAITING_EMOJI_ID] = None
            await query.edit_message_text(
                "🎨 <b>Qaysi emojini premium qilmoqchisiz?</b>\n\n"
                "Emoji belgisini yuboring (masalan: ⏰).",
                reply_markup=keyboards.admin_back_kb(),
                parse_mode=ParseMode.HTML,
            )
            return
        if data.startswith("emoji:del:"):
            char = data[len("emoji:del:"):]
            storage.remove_premium_emoji(char)
            _pemoji.invalidate_cache()
            emoji_map = storage.get_premium_emoji_map()
            await query.edit_message_text(
                texts.admin_emoji_text(emoji_map),
                reply_markup=keyboards.admin_emoji_kb(emoji_map),
                parse_mode=ParseMode.HTML,
            )
            return

    if data == "admin:givepro":
        _clear_admin_waiting(context)
        context.user_data[WAITING_ADMIN_GIVEPRO_USER] = True
        await query.edit_message_text(
            texts.admin_give_pro_text(),
            reply_markup=keyboards.admin_cancel_kb(),
            parse_mode=ParseMode.HTML,
        )
        return

    if len(parts) == 3 and parts[1] in ("giveprouser", "removepro"):
        try:
            target_id = int(parts[2])
        except ValueError:
            await query.answer("Noto'g'ri ID.", show_alert=True)
            return
        if parts[1] == "giveprouser":
            storage.give_pro(target_id, days=30)
            storage.log_admin_action("givepro", target_id, "30 kun")
            await query.answer("💎 Pro tarif 30 kunlik berildi.")
        else:
            storage.remove_pro(target_id)
            storage.log_admin_action("removepro", target_id)
            await query.answer("❌ Pro tarif bekor qilindi.")
        await _show_admin_user_card(query, context, target_id)
        return

    if len(parts) == 3 and parts[1] in ("ban", "banconfirm", "cancelban", "unban", "resetauto", "addbal"):
        action = parts[1]
        try:
            target_id = int(parts[2])
        except ValueError:
            await query.answer("Noto'g'ri ID.", show_alert=True)
            return

        if action == "ban":
            # Bloklash — qaytarilishi qiyin ta'sirga ega, shuning uchun
            # darhol bajarmasdan avval tasdiqlash ekranini ko'rsatamiz.
            target = storage.find_existing(target_id)
            if target is None:
                await query.answer("Foydalanuvchi topilmadi.", show_alert=True)
                return
            await query.edit_message_text(
                texts.admin_ban_confirm_text(target),
                reply_markup=keyboards.admin_ban_confirm_kb(target_id),
                parse_mode=ParseMode.HTML,
            )
            return

        if action == "banconfirm":
            storage.set_banned(target_id, True)
            storage.log_admin_action("ban", target_id)
            await query.answer("\U0001f6ab Bloklandi.")
            await _show_admin_user_card(query, context, target_id)
            return

        if action == "cancelban":
            await query.answer("Bekor qilindi.")
            await _show_admin_user_card(query, context, target_id)
            return

        if action == "unban":
            storage.set_banned(target_id, False)
            storage.log_admin_action("unban", target_id)
            await query.answer("\u2705 Blokdan chiqarildi.")
            await _show_admin_user_card(query, context, target_id)
            return

        if action == "resetauto":
            storage.reset_autoreply_sent(target_id)
            storage.log_admin_action("resetauto", target_id)
            await query.answer("\u267b\ufe0f Avto-javob xotirasi tozalandi.")
            await _show_admin_user_card(query, context, target_id)
            return

        if action == "addbal":
            context.user_data[WAITING_ADMIN_ADDBAL_USER] = target_id
            await query.edit_message_text(
                f"\U0001f4b0 <code>{target_id}</code> foydalanuvchisiga qo'shiladigan "
                "summani yozing (so'm), masalan: <code>5000</code>",
                reply_markup=keyboards.admin_cancel_kb(),
                parse_mode=ParseMode.HTML,
            )
            return


# ------------------------------------------------------------- callbacks ---
async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    try:
        await _dispatch_callback(update, context, query, data)
    except Exception as e:
        # MUHIM: agar shu yergacha query.answer() chaqirilmagan bo'lsa,
        # Telegram tugmani "yuklanmoqda..." holatida abadiy qotirib qo'yadi
        # (masalan tarmoq uzilishi — ConnectTimeout — tufayli). Shu sabab
        # xato yuz berganda ham DARHOL javob berishga urinib ko'ramiz, shunda
        # foydalanuvchi kamida "vaqtincha xatolik" xabarini ko'radi va
        # tugma qotib qolmaydi.
        logger.warning("on_callback xato (data=%s): %s", data, e)
        try:
            await query.answer("⚠️ Vaqtincha muammo yuz berdi. Birozdan so'ng qayta urinib ko'ring.", show_alert=True)
        except Exception:
            pass


async def _dispatch_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, query, data):

    if data.startswith("admin_topup:"):
        await payments.admin_topup_decision(update, context)
        return

    if data.startswith("admin:") or data.startswith("emoji:"):
        await query.answer()
        await _admin_callback(query, context, update)
        return

    user_tg = update.effective_user
    user = storage.get(user_tg.id, user_tg.first_name)

    if user.is_banned:
        await query.answer(texts.banned_notice_text(), show_alert=True)
        return

    # Botni akkauntga ulamagan foydalanuvchi shu bo'limlardan foydalana
    # olmaydi — avval "Botni ulash" qilishi kerakligini ko'rsatamiz.
    _NEEDS_CONNECTION_EXACT = {
        "menu:settings", "menu:autoreplies", "menu:soat", "menu:chatbot_settings",
        "menu:contacts", "menu:keywords", "kwadd",
    }
    _NEEDS_CONNECTION_PREFIX = (
        "cbset:", "cbtext:", "soat:", "set:", "contact:", "contact_tag:",
        "contact_note:", "kwdel:",
    )
    if not user.connected and (
        data in _NEEDS_CONNECTION_EXACT or data.startswith(_NEEDS_CONNECTION_PREFIX)
    ):
        await query.answer(
            "🔗 Avval botni akkauntingizga ulang: \"🔗 Botni ulash\" tugmasini bosing.",
            show_alert=True,
        )
        return

    await query.answer()

    if data == "menu:home":
        fresh = storage.get(user.user_id)
        await query.edit_message_text(
            texts.welcome_text(user_tg.first_name, connected=fresh.connected),
            reply_markup=keyboards.main_menu_kb(fresh.connected, is_admin=_is_admin(update)),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:profile":
        await query.edit_message_text(
            texts.profile_text(user),
            reply_markup=keyboards.profile_kb(user.tariff),
            parse_mode=ParseMode.HTML,
        )

    elif data == "tariff:info:free":
        if user.tariff == "pro":
            await query.answer(
                "Siz hozir 💎 Pro tarifdasiz. Bepulga tushish uchun admin bilan bog'laning.",
                show_alert=True,
            )
        else:
            await query.answer("✅ Siz hozir shu (🆓 Bepul) tarifdasiz.", show_alert=True)

    elif data == "tariff:info:pro":
        await query.answer("✅ Siz hozir 💎 Pro tarifdasiz.", show_alert=True)

    elif data == "menu:guide":
        await query.edit_message_text(
            texts.tariff_compare_text(),
            reply_markup=keyboards.back_kb(),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:commands":
        await query.edit_message_text(
            texts.HELP_TEXT,
            reply_markup=keyboards.back_kb(),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:settings":
        await query.edit_message_text(
            texts.settings_text(user),
            reply_markup=keyboards.settings_kb(user),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:connect":
        await query.edit_message_text(
            texts.connect_bot_text(),
            reply_markup=keyboards.connect_kb(),
            parse_mode=ParseMode.HTML,
        )

    elif data == "connect:check":
        # Haqiqiy holatni ko'rsatamiz — business_connection update kelganidamas,
        # foydalanuvchi haqiqatan ulaganida user.connected True bo'ladi.
        fresh = storage.get(user.user_id)
        if fresh.connected:
            await query.edit_message_text(
                "\u2705 Bot akkauntingizga ulangan va avto-javob ishlamoqda!",
                reply_markup=keyboards.back_kb(),
                parse_mode=ParseMode.HTML,
            )
        else:
            await query.answer(
                "Hali ulanmagan. Telegram Sozlamalar > Telegram Business > "
                "Chatbots bo'limidan botni qo'shing.",
                show_alert=True,
            )

    elif data == "menu:referral":
        await query.edit_message_text(
            texts.referral_text(user.user_id),
            reply_markup=keyboards.back_kb("menu:profile"),
            parse_mode=ParseMode.HTML,
        )

    elif data.startswith("tariff:"):
        chosen = data.split(":", 1)[1]
        if chosen == user.tariff:
            await query.answer("Bu tarif allaqachon faol.", show_alert=False)
        elif chosen == "free":
            storage.set_tariff(user.user_id, "free")
            user = storage.get(user.user_id)
            await query.answer("Bepul tarifga o'tdingiz.")
        else:
            info = TARIFFS[chosen]
            if info['price_month'] > 0 and storage.deduct_balance_som(user.user_id, info['price_month']):
                storage.set_tariff(user.user_id, chosen)
                user = storage.get(user.user_id)
                await query.answer(f"{info['title']} tarifi faollashtirildi \u2705")
            else:
                await query.answer(
                    f"Balansingizda mablag' yetarli emas. {info['title']} tarifi narxi: "
                    f"{info['price_month']:,} so'm/oy. Balansni to'ldiring.".replace(",", " "),
                    show_alert=True,
                )
        await query.edit_message_text(
            texts.profile_text(user),
            reply_markup=keyboards.profile_kb(user.tariff),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:buy_pro":
        await query.edit_message_text(
            texts.buy_pro_text(user),
            reply_markup=keyboards.buy_pro_kb(),
            parse_mode=ParseMode.HTML,
        )

    elif data.startswith("pro:buy:"):
        method = data.split(":")[-1]  # "card" yoki "stars"
        pro = TARIFFS["pro"]
        price = pro["price_month"]
        if user.tariff == "pro" and user.is_pro:
            await query.answer("💎 Pro tarif allaqachon faol!", show_alert=True)
            return
        if method == "card":
            if user.balance_som >= price:
                storage.deduct_balance_som(user.user_id, price)
                storage.give_pro(user.user_id, days=30)
                user = storage.get(user.user_id)
                await query.answer("✅ Pro tarif faollashtirildi!", show_alert=True)
                await query.edit_message_text(
                    texts.profile_text(user),
                    reply_markup=keyboards.profile_kb(user.tariff),
                    parse_mode=ParseMode.HTML,
                )
            else:
                need = price - user.balance_som
                await query.answer(
                    f"Balansingiz yetarli emas. Kamida {need:,} so'm to'ldiring.".replace(",", " "),
                    show_alert=True,
                )
        elif method == "stars":
            await query.answer(
                "⭐ Stars orqali to'lash: balansni to'ldirish bo'limida Stars yuboring, "
                "keyin Pro'ni karta orqali to'lang.",
                show_alert=True,
            )

    elif data == "menu:balance":
        await query.edit_message_text(
            texts.balance_menu_text(user),
            reply_markup=keyboards.balance_methods_kb(),
            parse_mode=ParseMode.HTML,
        )

    elif data == "balance:stars":
        context.user_data[WAITING_AMOUNT] = True
        context.user_data[WAITING_AMOUNT_METHOD] = "stars"
        await query.edit_message_text(
            "\u2b50 Nechta Stars sotib olmoqchisiz? Raqam yuboring (masalan: 50)",
            reply_markup=keyboards.back_kb("menu:balance"),
            parse_mode=ParseMode.HTML,
        )

    elif data == "balance:card":
        context.user_data[WAITING_AMOUNT] = True
        context.user_data[WAITING_AMOUNT_METHOD] = "card"
        await query.edit_message_text(
            texts.ask_amount_text(),
            reply_markup=keyboards.back_kb("menu:balance"),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:autoreplies":
        limit = user.tariff_info()['auto_reply_limit']
        await query.edit_message_text(
            texts.autoreplies_text(user, limit),
            reply_markup=keyboards.autoreplies_kb(),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:soat":
        if not await _require_pro(query, user, "soat"):
            return
        await query.edit_message_text(
            texts.soat_text(user),
            reply_markup=keyboards.soat_kb(user),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:chatbot_settings":
        await query.edit_message_text(
            texts.chatbot_settings_text(user),
            reply_markup=keyboards.chatbot_settings_kb(user),
            parse_mode=ParseMode.HTML,
        )

    elif data.startswith("cbset:"):
        await handle_chatbot_setting_callback(query, context, user, data)

    elif data.startswith("cbtext:"):
        key = data.split(":", 1)[1]
        context.user_data[WAITING_SETTING_INPUT] = key
        prompts = {
            "edit_notify_text": "✏️ Xabar tahrirlanganda suhbatdoshga yuboriladigan matnni yozing:",
            "delete_notify_text": "🗑 Xabar o'chirilganda suhbatdoshga yuboriladigan matnni yozing:",
            "work_hours_range": "🕘 Ish vaqtini <code>09:00-18:00</code> formatida yozing:",
            "after_hours_text": "🌙 Ish vaqtidan tashqarida yuboriladigan matnni yozing "
                                 "(bo'sh qoldirish uchun bitta bo'sh joy yuboring):",
        }
        await query.edit_message_text(
            prompts.get(key, "Matnni yozing:"),
            reply_markup=keyboards.back_kb("menu:chatbot_settings"),
            parse_mode=ParseMode.HTML,
        )

    elif data == "spyconsent:yes":
        await handle_spy_consent(query, context, user, agreed=True)

    elif data == "spyconsent:no":
        await handle_spy_consent(query, context, user, agreed=False)

    elif data.startswith("soat:"):
        await handle_soat_callback(query, context, user, data)

    elif data.startswith("set:"):
        await handle_setting_callback(query, context, user, data)

    elif data == "menu:contacts":
        contacts = storage.list_contacts(user.user_id, limit=20)
        await query.edit_message_text(
            texts.contacts_list_text(contacts),
            reply_markup=keyboards.contacts_list_kb(contacts),
            parse_mode=ParseMode.HTML,
        )

    elif data.startswith("contact:"):
        chat_id = int(data.split(":", 1)[1])
        c = storage.get_contact(user.user_id, chat_id)
        if c is None:
            await query.answer("Topilmadi.", show_alert=True)
            return
        await query.edit_message_text(
            texts.contact_card_text(c),
            reply_markup=keyboards.contact_card_kb(chat_id),
            parse_mode=ParseMode.HTML,
        )

    elif data.startswith("contact_tag:"):
        _, chat_id_s, tag = data.split(":", 2)
        chat_id = int(chat_id_s)
        storage.set_contact_tag(user.user_id, chat_id, tag)
        c = storage.get_contact(user.user_id, chat_id)
        await query.answer("✅ Teg qo'yildi.")
        await query.edit_message_text(
            texts.contact_card_text(c),
            reply_markup=keyboards.contact_card_kb(chat_id),
            parse_mode=ParseMode.HTML,
        )

    elif data.startswith("contact_note:"):
        chat_id = int(data.split(":", 1)[1])
        context.user_data[WAITING_CONTACT_NOTE] = chat_id
        await query.edit_message_text(
            "📝 Bu mijoz uchun izohni yozing:",
            reply_markup=keyboards.back_kb(f"contact:{chat_id}"),
            parse_mode=ParseMode.HTML,
        )

    elif data == "menu:keywords":
        rows = storage.list_keyword_replies(user.user_id)
        await query.edit_message_text(
            texts.keywords_text(rows),
            reply_markup=keyboards.keywords_kb(rows),
            parse_mode=ParseMode.HTML,
        )

    elif data == "kwadd":
        context.user_data[WAITING_KEYWORD_ADD] = True
        await query.edit_message_text(
            "🔑 Kalit so'z va javobni <b>| (vertikal chiziq)</b> bilan ajratib yozing.\n\n"
            "Masalan:\n<code>narx | Narximiz 50 000 so'mdan boshlanadi.</code>",
            reply_markup=keyboards.back_kb("menu:keywords"),
            parse_mode=ParseMode.HTML,
        )

    elif data.startswith("kwdel:"):
        kw_id = int(data.split(":", 1)[1])
        storage.delete_keyword_reply(user.user_id, kw_id)
        rows = storage.list_keyword_replies(user.user_id)
        await query.answer("🗑 O'chirildi.")
        await query.edit_message_text(
            texts.keywords_text(rows),
            reply_markup=keyboards.keywords_kb(rows),
            parse_mode=ParseMode.HTML,
        )


async def handle_spy_consent(query, context, user, agreed: bool):
    if agreed:
        user.settings.spy_mode = True
        storage.save(user)
        if user.telethon_session:
            # Shaxsiy akkauntga (Business orqali emas, oddiy DM) kelgan
            # xabarlar uchun ham Telethon tinglovchisini ulaymiz.
            import spy as spy_module
            try:
                await spy_module.ensure_spy_running(_storage_module(), user)
            except Exception as e:
                logger.warning("Spy: ulanmadi user=%s: %s", user.user_id, e)
        await query.answer("✅ Shpion rejimi yoqildi.")
    else:
        # spy_mode allaqachon False — hech narsa o'zgartirmaymiz.
        await query.answer("❌ Bekor qilindi, shpion rejimi off holida qoladi.")
    await query.edit_message_text(
        texts.settings_text(user),
        reply_markup=keyboards.settings_kb(user),
        parse_mode=ParseMode.HTML,
    )


async def handle_chatbot_setting_callback(query, context, user, data):
    key = data.split(":", 1)[1]
    s = user.settings

    if key == "autoreply_mode":
        # "once" <-> "always" o'rtasida almashtiradi (business.py da ishlatiladi).
        s.autoreply_mode = "always" if s.autoreply_mode == "once" else "once"
        storage.save(user)
        await query.answer(
            "\U0001f501 Endi: " + ("har doim javob beriladi." if s.autoreply_mode == "always"
                                    else "faqat 1 marta javob beriladi.")
        )
        await query.edit_message_text(
            texts.chatbot_settings_text(user),
            reply_markup=keyboards.chatbot_settings_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return

    if key == "reset_autoreply":
        storage.reset_autoreply_sent(user.user_id)
        await query.answer("\u267b\ufe0f Tozalandi — endi hammaga qayta 1 martadan yuboriladi.")
        await query.edit_message_text(
            texts.chatbot_settings_text(user),
            reply_markup=keyboards.chatbot_settings_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return

    if key == "work_hours_enabled":
        s.work_hours_enabled = not s.work_hours_enabled
        storage.save(user)
        await query.answer("⏰ Ish vaqti: " + ("yoqildi" if s.work_hours_enabled else "o'chirildi"))
        await query.edit_message_text(
            texts.chatbot_settings_text(user),
            reply_markup=keyboards.chatbot_settings_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return

    if key == "edit_notify":
        # Suhbatdosh o'z xabarini tahrirlaganda, o'sha suhbatga avtomatik
        # javob (edit_notify_text) yuboriladi (business.py da).
        s.edit_notify = not s.edit_notify
    elif key == "delete_notify":
        # Suhbatdosh o'z xabarini o'chirganda, o'sha suhbatga avtomatik
        # javob (delete_notify_text) yuboriladi (business.py da).
        s.delete_notify = not s.delete_notify
    elif key == "apk_autodelete":
        # Suhbatdosh yuborgan .apk fayllar avtomatik o'chiriladi — buning
        # uchun botni ulaganda "Xabarlarni o'chirish" huquqi berilgan
        # bo'lishi kerak (Telegram Business > Chatbots sozlamalarida).
        s.apk_autodelete = not s.apk_autodelete
    elif key == "typing_notify":
        # Avto-javob yuborishdan oldin "yozmoqda..." holatini ko'rsatadi.
        s.typing_notify = not s.typing_notify

    storage.save(user)
    await query.edit_message_text(
        texts.chatbot_settings_text(user),
        reply_markup=keyboards.chatbot_settings_kb(user),
        parse_mode=ParseMode.HTML,
    )


async def handle_setting_callback(query, context, user, data):
    key = data.split(":", 1)[1]
    s = user.settings

    if key == "online_24_7":
        # Bu tugma ikki narsani boshqaradi:
        #  1) Avto-javobning bosh o'chirgichi (business.py) — telethon shart
        #     emas, darhol ishlaydi.
        #  2) Hisob HAQIQATAN "online" (yashil nuqta) deb belgilanadi — buning
        #     uchun Telethon (telefon+kod) orqali bir marta tasdiqlash kerak.
        if s.online_24_7:
            # O'chirish — tasdiqsiz, darhol.
            s.online_24_7 = False
            storage.save(user)
        else:
            if not await _require_pro(query, user, "online"):
                return
            if not profile_clock.soat_configured():
                await query.answer(texts.soat_not_configured_text(), show_alert=True)
                return
            if not user.telethon_session:
                # Sessiya yo'q (yoki oldin bekor qilingan) — login jarayonini
                # boshlaymiz, login tugagach "online" AVTOMATIK yoqiladi.
                context.user_data[WAITING_SOAT_PHONE] = True
                context.user_data[WAITING_SOAT_PURPOSE] = "online"
                await query.edit_message_text(
                    texts.soat_ask_phone_text(),
                    reply_markup=keyboards.back_kb("menu:settings"),
                    parse_mode=ParseMode.HTML,
                )
                return
            s.online_24_7 = True
            storage.save(user)
            await profile_clock.update_one_online(user, storage_module=_storage_module(), bot=context.bot)
        await query.edit_message_text(
            texts.settings_text(user),
            reply_markup=keyboards.settings_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return
    elif key == "spy_mode":
        if s.spy_mode:
            # O'chirish — tasdiqsiz, darhol.
            s.spy_mode = False
        else:
            if not await _require_pro(query, user, "spy"):
                return
            # Yoqish — avval rozilik so'raymiz (pastdagi
            # handle_spy_consent funksiyasida yakunlanadi).
            await query.edit_message_text(
                texts.SPY_CONSENT_TEXT,
                reply_markup=keyboards.spy_consent_kb(),
                parse_mode=ParseMode.HTML,
            )
            return
    elif key in ("ok_text", "loc_text"):
        context.user_data[WAITING_SETTING_INPUT] = key
        prompts = {
            "ok_text": "\u2709\ufe0f Yangi «.ok» matnini yozing:",
            "loc_text": "\U0001f4cd Yangi «.loc» matnini yozing:",
        }
        await query.edit_message_text(
            prompts[key],
            reply_markup=keyboards.back_kb("menu:settings"),
            parse_mode=ParseMode.HTML,
        )
        return

    storage.save(user)
    await query.edit_message_text(
        texts.settings_text(user),
        reply_markup=keyboards.settings_kb(user),
        parse_mode=ParseMode.HTML,
    )


async def handle_soat_callback(query, context, user, data):
    parts = data.split(":")
    action = parts[1]

    if action == "toggle":
        if not user.settings.profil_soat:
            if not await _require_pro(query, user, "soat"):
                return
            # Hali sozlanmagan bo'lsa — foydalanuvchini xabardor qilamiz
            if not profile_clock.soat_configured():
                await query.answer(texts.soat_not_configured_text(), show_alert=True)
                return
            if not user.telethon_session:
                # Login jarayonini boshlaymiz — telefon raqamini so'raymiz
                context.user_data[WAITING_SOAT_PHONE] = True
                context.user_data[WAITING_SOAT_PURPOSE] = "soat"
                await query.edit_message_text(
                    texts.soat_ask_phone_text(),
                    reply_markup=keyboards.back_kb("menu:soat"),
                    parse_mode=ParseMode.HTML,
                )
                return
            user.settings.profil_soat = True
            storage.save(user)
            await profile_clock.update_one_clock(_storage_module(), user)
            await query.edit_message_text(
                texts.soat_text(user),
                reply_markup=keyboards.soat_kb(user),
                parse_mode=ParseMode.HTML,
            )
            return
        else:
            user.settings.profil_soat = False
            await profile_clock.disable_and_restore(_storage_module(), user)
        storage.save(user)
        await query.edit_message_text(
            texts.soat_text(user),
            reply_markup=keyboards.soat_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return

    if action == "font":
        font_key = parts[2]
        if font_key in profile_clock.FONT_STYLES:
            user.settings.soat_font = font_key
            storage.save(user)
            if user.settings.profil_soat:
                await profile_clock.update_one_clock(_storage_module(), user)
        await query.edit_message_text(
            texts.soat_text(user),
            reply_markup=keyboards.soat_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return

    if action == "sep":
        user.settings.soat_sep = not user.settings.soat_sep
        storage.save(user)
        if user.settings.profil_soat:
            await profile_clock.update_one_clock(_storage_module(), user)
        await query.edit_message_text(
            texts.soat_text(user),
            reply_markup=keyboards.soat_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return


def _storage_module():
    import storage as storage_module
    return storage_module


async def _require_pro(query, user, feature_label: str) -> bool:
    """⏰ Profilga soat, 🟢 24/7 online va 🕵️ Shpion rejimi — faqat 💎 Pro
    tarifida. Start (bepul) tarifda bo'lsa, ogohlantirib, False qaytaradi
    (chaqiruvchi shu holda hech narsa qilmasligi kerak)."""
    if user.has_feature("soat_enabled") if feature_label == "soat" else (
        user.has_feature("online_enabled") if feature_label == "online" else
        user.has_feature("spy_enabled")
    ):
        return True
    await query.answer(
        f"💎 {feature_label.capitalize()} bo'limi faqat Pro tarifida mavjud.\n"
        "👤 Profilim → tarifni Pro ga o'zgartiring.",
        show_alert=True,
    )
    return False


# --------------------------------------------------- oddiy matn xabarlari ---
async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message is None:
        # Xavfsizlik uchun qo'shimcha tekshiruv: bu handler faqat oddiy shaxsiy
        # xabarlar uchun ishlaydi (business_message'lar business.py da).
        return
    user_tg = update.effective_user
    user = storage.get(user_tg.id, user_tg.first_name)
    text = update.message.text or ""

    if user.is_banned:
        await update.message.reply_text(texts.banned_notice_text())
        return

    # 0) «Profilga soat» login jarayoni (telefon -> kod -> [parol])
    if context.user_data.get(WAITING_SOAT_PHONE):
        context.user_data[WAITING_SOAT_PHONE] = False
        phone = text.strip()
        if not phone.startswith("+") or not phone[1:].replace(" ", "").isdigit():
            await update.message.reply_text(
                "⚠️ Telefon raqamini xalqaro formatda yuboring, masalan: +998901234567"
            )
            context.user_data[WAITING_SOAT_PHONE] = True
            return
        try:
            await profile_clock.start_login(user.user_id, phone)
            context.user_data[WAITING_SOAT_CODE] = True
            await update.message.reply_text(texts.soat_ask_code_text(), parse_mode=ParseMode.HTML)
        except Exception as e:
            await update.message.reply_text(f"⚠️ Xatolik: {e}")
        return

    if context.user_data.get(WAITING_SOAT_CODE):
        context.user_data[WAITING_SOAT_CODE] = False
        # Foydalanuvchi kodni "12.345" kabi (orasiga nuqta qo'yib) yuborishi
        # mumkin — bu Telegram ilovasi login kodini avtomatik "yashirib" 
        # qo'ymasligi uchun tavsiya qilingan. Bot tomonida nuqta/bo'sh joy
        # olib tashlanadi.
        code = text.strip().replace(" ", "").replace(".", "").replace("-", "")
        try:
            result = await profile_clock.confirm_code(user.user_id, code)
            if result == "need_password":
                context.user_data[WAITING_SOAT_PASSWORD] = True
                await update.message.reply_text(texts.soat_ask_password_text(), parse_mode=ParseMode.HTML)
                return
            await _finish_soat_login(update, context, user)
        except Exception as e:
            await update.message.reply_text(f"⚠️ Xatolik: {e}")
        return

    if context.user_data.get(WAITING_SOAT_PASSWORD):
        context.user_data[WAITING_SOAT_PASSWORD] = False
        try:
            await profile_clock.confirm_password(user.user_id, text.strip())
            await _finish_soat_login(update, context, user)
        except Exception as e:
            await update.message.reply_text(f"⚠️ Xatolik: {e}")
        return

    # 0.4) Admin: foydalanuvchi ID qidirilmoqda
    if context.user_data.get(WAITING_ADMIN_USER_SEARCH) and _is_admin(update):
        context.user_data[WAITING_ADMIN_USER_SEARCH] = False
        raw = text.strip()
        if not raw.lstrip("-").isdigit():
            context.user_data[WAITING_ADMIN_USER_SEARCH] = True
            await update.message.reply_text(
                "⚠️ Iltimos, faqat Telegram ID raqamini yuboring (masalan: 123456789).",
                reply_markup=keyboards.admin_cancel_kb(),
            )
            return
        target_id = int(raw)
        target = storage.find_existing(target_id)
        if target is None:
            await update.message.reply_text(
                texts.admin_user_not_found_text(target_id),
                reply_markup=keyboards.admin_back_kb(),
                parse_mode=ParseMode.HTML,
            )
        else:
            await update.message.reply_text(
                texts.admin_user_card_text(target),
                reply_markup=keyboards.admin_user_kb(target),
                parse_mode=ParseMode.HTML,
            )
        return

    # 0.45) Admin: foydalanuvchiga qo'shiladigan balans summasi kutilmoqda
    admin_addbal_target = context.user_data.get(WAITING_ADMIN_ADDBAL_USER)
    if admin_addbal_target is not None and _is_admin(update):
        context.user_data[WAITING_ADMIN_ADDBAL_USER] = None
        if not text.strip().lstrip("-").isdigit():
            context.user_data[WAITING_ADMIN_ADDBAL_USER] = admin_addbal_target
            await update.message.reply_text(
                "⚠️ Iltimos, faqat raqam kiriting. Masalan: 5000",
                reply_markup=keyboards.admin_cancel_kb(),
            )
            return
        amount = int(text.strip())
        storage.add_balance_som(admin_addbal_target, amount)
        storage.log_admin_action("addbal", admin_addbal_target, f"{amount} som")
        target = storage.get(admin_addbal_target)
        await update.message.reply_text(
            f"\u2705 {amount:,} so'm qo'shildi.".replace(",", " "),
            reply_markup=keyboards.admin_user_kb(target),
        )
        try:
            await context.bot.send_message(
                chat_id=admin_addbal_target,
                text=f"\U0001f4b0 Balansingizga {amount:,} so'm qo'shildi.".replace(",", " "),
            )
        except Exception:
            pass
        return

    # 0.46a) Admin: givepro — user ID kutilmoqda
    if context.user_data.get(WAITING_ADMIN_GIVEPRO_USER) is True and _is_admin(update):
        context.user_data[WAITING_ADMIN_GIVEPRO_USER] = None
        raw = text.strip()
        if not raw.lstrip("-").isdigit():
            await update.message.reply_text("⚠️ Telegram ID raqamini yuboring.", reply_markup=keyboards.admin_cancel_kb())
            context.user_data[WAITING_ADMIN_GIVEPRO_USER] = True
            return
        tid = int(raw)
        if storage.find_existing(tid) is None:
            await update.message.reply_text(texts.admin_user_not_found_text(tid), reply_markup=keyboards.admin_back_kb(), parse_mode=ParseMode.HTML)
            return
        context.user_data[WAITING_ADMIN_GIVEPRO_USER] = tid
        context.user_data[WAITING_ADMIN_GIVEPRO_DAYS] = True
        await update.message.reply_text(
            f"💎 <code>{tid}</code> ga necha kun Pro berish? (masalan: <code>30</code>)",
            reply_markup=keyboards.admin_cancel_kb(), parse_mode=ParseMode.HTML)
        return

    if context.user_data.get(WAITING_ADMIN_GIVEPRO_DAYS) and _is_admin(update):
        context.user_data[WAITING_ADMIN_GIVEPRO_DAYS] = False
        tid = context.user_data.pop(WAITING_ADMIN_GIVEPRO_USER, None)
        if not text.strip().isdigit() or int(text.strip()) < 1:
            await update.message.reply_text("⚠️ Kun sonini yuboring (masalan: 30)", reply_markup=keyboards.admin_cancel_kb())
            context.user_data[WAITING_ADMIN_GIVEPRO_DAYS] = True
            context.user_data[WAITING_ADMIN_GIVEPRO_USER] = tid
            return
        days = int(text.strip())
        target = storage.give_pro(tid, days=days)
        storage.log_admin_action("givepro", tid, f"{days} kun")
        try:
            await context.bot.send_message(chat_id=tid, text=f"🎉 Tabriklaymiz! Sizga <b>{days} kunlik 💎 Pro tarif</b> berildi.", parse_mode="HTML")
        except Exception:
            pass
        await update.message.reply_text(
            f"✅ <code>{tid}</code> ga {days} kunlik Pro berildi.",
            reply_markup=keyboards.admin_user_kb(target), parse_mode=ParseMode.HTML)
        return

    # 0.46b) Admin: emoji char kutilmoqda
    if context.user_data.get(WAITING_EMOJI_CHAR) and _is_admin(update):
        context.user_data[WAITING_EMOJI_CHAR] = False
        char = text.strip()
        if len(char) == 0:
            await update.message.reply_text("⚠️ Emoji yuboring.", reply_markup=keyboards.admin_back_kb())
            return
        context.user_data[WAITING_EMOJI_ID] = char
        await update.message.reply_text(
            f"✅ Emoji: {char}\n\n"
            "Endi shu emojining <b>custom_emoji_id</b> raqamini yuboring.\n"
            "<i>Masalan: <code>5368324170671202286</code></i>",
            reply_markup=keyboards.admin_back_kb(), parse_mode=ParseMode.HTML)
        return

    if context.user_data.get(WAITING_EMOJI_ID) is not None and not context.user_data.get(WAITING_EMOJI_CHAR) and _is_admin(update):
        char = context.user_data.pop(WAITING_EMOJI_ID, None)
        if char is None:
            return
        cid = text.strip()
        if not cid.isdigit():
            await update.message.reply_text("⚠️ custom_emoji_id faqat raqam bo'lishi kerak.", reply_markup=keyboards.admin_back_kb())
            context.user_data[WAITING_EMOJI_ID] = char
            return
        import pemoji as _pemoji
        storage.set_premium_emoji(char, cid)
        _pemoji.invalidate_cache()
        emoji_map = storage.get_premium_emoji_map()
        await update.message.reply_text(
            f"✅ {char} → <code>{cid}</code> saqlandi!\n\n" + texts.admin_emoji_text(emoji_map),
            reply_markup=keyboards.admin_emoji_kb(emoji_map),
            parse_mode=ParseMode.HTML)
        return

    # 0.46) 👥 Mijoz uchun izoh matni kutilmoqda
    contact_note_chat_id = context.user_data.get(WAITING_CONTACT_NOTE)
    if contact_note_chat_id is not None:
        context.user_data[WAITING_CONTACT_NOTE] = None
        storage.set_contact_note(user.user_id, contact_note_chat_id, text.strip())
        c = storage.get_contact(user.user_id, contact_note_chat_id)
        await update.message.reply_text(
            "✅ Izoh saqlandi.\n\n" + texts.contact_card_text(c),
            reply_markup=keyboards.contact_card_kb(contact_note_chat_id),
            parse_mode=ParseMode.HTML,
        )
        return

    # 0.47) 🔑 Yangi kalit so'zli javob kutilmoqda ("so'z | javob" formatida)
    if context.user_data.get(WAITING_KEYWORD_ADD):
        context.user_data[WAITING_KEYWORD_ADD] = False
        if "|" not in text:
            await update.message.reply_text(
                "⚠️ Format: <code>so'z | javob matni</code> — orasiga | belgisini qo'ying.",
                parse_mode=ParseMode.HTML,
            )
            context.user_data[WAITING_KEYWORD_ADD] = True
            return
        kw, reply = text.split("|", 1)
        kw, reply = kw.strip(), reply.strip()
        if not kw or not reply:
            await update.message.reply_text("⚠️ Kalit so'z va javob bo'sh bo'lmasligi kerak.")
            context.user_data[WAITING_KEYWORD_ADD] = True
            return
        storage.add_keyword_reply(user.user_id, kw, reply)
        rows = storage.list_keyword_replies(user.user_id)
        await update.message.reply_text(
            "✅ Qo'shildi.\n\n" + texts.keywords_text(rows),
            reply_markup=keyboards.keywords_kb(rows),
            parse_mode=ParseMode.HTML,
        )
        return

    # 0.5) Admin: hammaga xabar yuborish matni kutilmoqda — darhol
    # yubormasdan, avval oldindan ko'rish + tasdiqlash ekranini chiqaramiz
    # (xato matn butun foydalanuvchi bazasiga ketib qolmasligi uchun).
    if context.user_data.get(WAITING_BROADCAST_TEXT) and _is_admin(update):
        context.user_data[WAITING_BROADCAST_TEXT] = False
        context.user_data[ADMIN_BROADCAST_PENDING_TEXT] = text
        total = len(storage.all_user_ids())
        await update.message.reply_text(
            texts.admin_broadcast_preview_text(text, total),
            reply_markup=keyboards.admin_broadcast_confirm_kb(),
            parse_mode=ParseMode.HTML,
        )
        return

    # 1) Balansni to'ldirish summasi kutilmoqda
    if context.user_data.get(WAITING_AMOUNT):
        context.user_data[WAITING_AMOUNT] = False
        method = context.user_data.get(WAITING_AMOUNT_METHOD, "card")
        if not text.strip().isdigit():
            await update.message.reply_text("Iltimos, faqat raqam kiriting. Masalan: 5000")
            return
        amount = int(text.strip())

        if method == "stars":
            if amount < 1:
                await update.message.reply_text("Kamida 1 Stars kiriting.")
                return
            await payments.send_stars_invoice(update, context, amount)
            return

        if amount < MIN_TOPUP_SOM:
            await update.message.reply_text(f"Eng kam summa {MIN_TOPUP_SOM} so'm. Qaytadan kiriting.")
            context.user_data[WAITING_AMOUNT] = True
            context.user_data[WAITING_AMOUNT_METHOD] = method
            return

        from config import PAYMENT_PROVIDER_TOKEN
        if PAYMENT_PROVIDER_TOKEN:
            await payments.send_card_invoice(update, context, amount)
        else:
            await payments.request_manual_card_topup(update, context, amount)
        return

    # 2) Sozlama matni kutilmoqda (.ok / .loc / tahrirlash-o'chirish
    #    bildirishnoma matnlari)
    waiting_key = context.user_data.get(WAITING_SETTING_INPUT)
    if waiting_key == "work_hours_range":
        context.user_data[WAITING_SETTING_INPUT] = None
        raw = text.strip()
        m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)\s*-\s*([01]?\d|2[0-3]):([0-5]\d)$", raw)
        if not m:
            await update.message.reply_text(
                "⚠️ Format noto'g'ri. Masalan: <code>09:00-18:00</code>",
                parse_mode=ParseMode.HTML,
            )
            context.user_data[WAITING_SETTING_INPUT] = "work_hours_range"
            return
        sh, sm, eh, em = m.groups()
        user.settings.work_hours_start = f"{int(sh):02d}:{sm}"
        user.settings.work_hours_end = f"{int(eh):02d}:{em}"
        storage.save(user)
        await update.message.reply_text("\u2705 Saqlandi.")
        await update.message.reply_text(
            texts.chatbot_settings_text(user),
            reply_markup=keyboards.chatbot_settings_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return
    if waiting_key:
        context.user_data[WAITING_SETTING_INPUT] = None
        setattr(user.settings, waiting_key, text.strip())
        storage.save(user)
        await update.message.reply_text("\u2705 Saqlandi.")
        if waiting_key in ("edit_notify_text", "delete_notify_text", "after_hours_text"):
            await update.message.reply_text(
                texts.chatbot_settings_text(user),
                reply_markup=keyboards.chatbot_settings_kb(user),
                parse_mode=ParseMode.HTML,
            )
        else:
            await update.message.reply_text(
                texts.settings_text(user),
                reply_markup=keyboards.settings_kb(user),
                parse_mode=ParseMode.HTML,
            )
        return

    # 3) Nuqta bilan boshlanuvchi buyruqlar (.ai, .dice, .help, ...)
    if text.startswith("."):
        from dotcommands import route_dot_command
        await route_dot_command(update, context, user, text)


async def _finish_soat_login(update: Update, context: ContextTypes.DEFAULT_TYPE, user):
    purpose = context.user_data.pop(WAITING_SOAT_PURPOSE, "soat")
    session_str, current_name = await profile_clock.finish_login(user.user_id)
    storage.set_telethon_session(user.user_id, session_str)
    if not user.base_first_name:
        storage.set_base_first_name(user.user_id, current_name or user.first_name)
    user = storage.get(user.user_id)

    if purpose == "online":
        user.settings.online_24_7 = True
        storage.save(user)
        ok = await profile_clock.update_one_online(user, storage_module=_storage_module(), bot=context.bot)
        if ok:
            await update.message.reply_text(
                "✅ Hisobingiz tasdiqlandi! Endi hisobingiz haqiqatan "
                "\U0001f7e2 <b>online</b> ko'rinishda turadi.",
                parse_mode=ParseMode.HTML,
            )
        else:
            await update.message.reply_text(
                "✅ Hisobingiz tasdiqlandi, lekin online holatini "
                "yangilashda xatolik yuz berdi. Bot avtomatik qayta "
                "urinib turadi."
            )
        await update.message.reply_text(
            texts.settings_text(user),
            reply_markup=keyboards.settings_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return

    if purpose == "spy":
        user.settings.spy_mode = True
        storage.save(user)
        import spy as spy_module
        await spy_module.ensure_spy_running(_storage_module(), user)
        await update.message.reply_text(
            "✅ Hisobingiz tasdiqlandi! \U0001f575\ufe0f Shpion rejimi endi "
            "shaxsiy xabarlaringiz uchun ham ishlaydi.",
            parse_mode=ParseMode.HTML,
        )
        await update.message.reply_text(
            texts.settings_text(user),
            reply_markup=keyboards.settings_kb(user),
            parse_mode=ParseMode.HTML,
        )
        return

    # purpose == "soat" (standart)
    user.settings.profil_soat = True
    storage.save(user)

    # Fon vazifasini (job_queue, har 60s) kutib o'tirmay, ismni DARHOL
    # yangilaymiz — job_queue biror sababga ko'ra ishlamay qolsa ham,
    # foydalanuvchi natijani shu zahoti ko'radi.
    ok = await profile_clock.update_one_clock(_storage_module(), user)

    if ok:
        await update.message.reply_text(
            "✅ Hisobingiz tasdiqlandi! Ismingizga jonli soat qo'yildi "
            f"(bundan keyin har {60} soniyada avtomatik yangilanib turadi)."
        )
    else:
        await update.message.reply_text(
            "✅ Hisobingiz tasdiqlandi, lekin ismga soat qo'yishda xatolik "
            "yuz berdi (Telegram tomonidan rad etilgan bo'lishi mumkin — "
            "masalan, ism juda tez-tez o'zgartirilsa Telegram vaqtincha "
            "cheklov qo'yadi). Bir necha daqiqadan so'ng avtomatik qayta "
            "urinib ko'riladi."
        )
    await update.message.reply_text(
        texts.soat_text(user),
        reply_markup=keyboards.soat_kb(user),
        parse_mode=ParseMode.HTML,
    )
