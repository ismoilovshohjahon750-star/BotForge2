"""
ArdoChat Bot — «Profilga soat» (HAQIQIY, userbot orqali).

Muhim texnik izoh: oddiy Bot API bilan bot HECH QACHON foydalanuvchining
o'z Telegram profil ismini (first_name) o'zgartira olmaydi — bu Telegram
tomonidan qo'yilgan cheklov (botlar faqat o'zining ismini o'zgartira oladi).
Haqiqiy "ismga jonli soat qo'shish" faqat foydalanuvchining o'z hisobi
nomidan ishlaydigan mijoz (Telethon "userbot") orqali mumkin — xuddi shu
sababdan bu funksiya alohida, ixtiyoriy login (telefon raqami + SMS/ilova
kodi) talab qiladi va faqat TELEGRAM_API_ID / TELEGRAM_API_HASH (my.telegram.org
saytidan bepul olinadi) .env ga qo'yilgan bo'lsa ishlaydi.

Sessiya (StringSession) SQLite bazasida saqlanadi. Bu — foydalanuvchining
akkauntiga to'liq kirish huquqi bilan teng, shuning uchun bazani va serverni
ishonchli joyda saqlash foydalanuvchining o'zi javobgarligida.
"""
import logging
from datetime import datetime

from config import TELEGRAM_API_ID, TELEGRAM_API_HASH

logger = logging.getLogger(__name__)

TELETHON_AVAILABLE = True
try:
    from telethon import TelegramClient
    from telethon.sessions import StringSession
    from telethon.errors import (
        SessionPasswordNeededError,
        PhoneCodeInvalidError,
        PhoneCodeExpiredError,
        FloodWaitError,
        UnauthorizedError,  # AuthKeyUnregistered/SessionRevoked/UserDeactivated... hammasi shundan meros
    )
    from telethon.tl.functions.account import UpdateProfileRequest, UpdateStatusRequest
except ImportError:  # telethon requirements.txt orqali o'rnatilmagan bo'lishi mumkin
    TELETHON_AVAILABLE = False

    class UnauthorizedError(Exception):
        pass


# Bot ishga tushganda bot.py orqali o'rnatiladi — job_queue tashqarisidagi
# joylardan (masalan spy.py ichidagi Telethon event handlerlaridan) ham
# foydalanuvchiga xabar yubora olish uchun.
_bot_ref = None


def set_bot_ref(bot):
    global _bot_ref
    _bot_ref = bot


async def _session_lost(storage_module, user, bot=None):
    """Foydalanuvchining Telethon sessiyasi endi ishlamay qolganda (masalan,
    foydalanuvchi botni/haqiqiy qurilmani Telegram'ning \"Faol sessiyalar\"
    bo'limidan chiqarib yuborsa) chaqiriladi: sessiyani bazadan tozalaydi,
    «Profilga soat» / «24/7 online» / «Shpion rejimi»ni o'chiradi va
    foydalanuvchiga aniq xabar yuboradi — shunda keyingi safar shu\n    bo'limlardan birini yoqishga urinsa, bot avtomatik qayta ulanishni\n    (telefon raqami so'rashni) boshlaydi."""
    try:
        storage_module.storage.set_telethon_session(user.user_id, None)
        fresh = storage_module.storage.get(user.user_id)
        fresh.settings.profil_soat = False
        fresh.settings.online_24_7 = False
        fresh.settings.spy_mode = False
        storage_module.storage.save(fresh)
    except Exception as e:
        logger.warning("Session lost: bazani tozalab bo'lmadi user=%s: %s", user.user_id, e)

    _active_clients.pop(user.user_id, None)
    _flood_wait_until.pop(user.user_id, None)
    _flood_notified.discard(user.user_id)

    the_bot = bot or _bot_ref
    if the_bot is not None:
        try:
            await the_bot.send_message(
                chat_id=user.user_id,
                text=(
                    "\u26a0\ufe0f <b>Botni Telegram akkountingizdan chiqarib "
                    "yubordingiz.</b>\n\n"
                    "Buni siz \"Sozlamalar \u2192 Qurilmalar / Faol sessiyalar\" "
                    "bo'limidan sessiyani tugatgan bo'lishingiz mumkin. Shu "
                    "sabab <b>\u23f0 Profilga soat</b>, <b>\U0001f7e2 24/7 "
                    "online</b> va <b>\U0001f575\ufe0f Shpion rejimi</b> "
                    "o'chirib qo'yildi.\n\n"
                    "Qaytadan yoqish uchun tegishli bo'limga kirib, "
                    "telefon raqamingizni yana bir marta yuboring — bot "
                    "sizni avtomatik qayta ulaydi."
                ),
                parse_mode="HTML",
            )
        except Exception as e:
            logger.warning("Session lost: xabar yuborilmadi user=%s: %s", user.user_id, e)


def soat_configured() -> bool:
    """TELEGRAM_API_ID/HASH .env ga qo'yilganmi va telethon o'rnatilganmi."""
    return TELETHON_AVAILABLE and bool(TELEGRAM_API_ID) and bool(TELEGRAM_API_HASH)


# --------------------------------------------------------------- fonts -----
# Rasmda ko'rsatilgan 6 xil ko'rinish (soat matnini turli unicode uslublarda
# chizish). Har biri (key, ko'rinish nomi, transform-funksiya) qaytaradi.

_CIRCLED = {"0": "⓪", "1": "①", "2": "②", "3": "③", "4": "④",
            "5": "⑤", "6": "⑥", "7": "⑦", "8": "⑧", "9": "⑨", ":": "："}
_FULLWIDTH = {"0": "０", "1": "１", "2": "２", "3": "３", "4": "４",
              "5": "５", "6": "６", "7": "７", "8": "８", "9": "９", ":": "："}
_BOLD = {"0": "𝟬", "1": "𝟭", "2": "𝟮", "3": "𝟯", "4": "𝟰",
         "5": "𝟱", "6": "𝟲", "7": "𝟳", "8": "𝟴", "9": "𝟵", ":": ":"}
_MONO = {"0": "𝟶", "1": "𝟷", "2": "𝟸", "3": "𝟹", "4": "𝟺",
         "5": "𝟻", "6": "𝟼", "7": "𝟽", "8": "𝟾", "9": "𝟿", ":": ":"}
_DOUBLE = {"0": "𝟘", "1": "𝟙", "2": "𝟚", "3": "𝟛", "4": "𝟜",
           "5": "𝟝", "6": "𝟞", "7": "𝟟", "8": "𝟠", "9": "𝟡", ":": ":"}
_SANS = {"0": "𝟢", "1": "𝟣", "2": "𝟤", "3": "𝟥", "4": "𝟦",
         "5": "𝟧", "6": "𝟨", "7": "𝟩", "8": "𝟪", "9": "𝟫", ":": ":"}
_SUPER = {"0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
          "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹", ":": "˸"}
_SUB = {"0": "₀", "1": "₁", "2": "₂", "3": "₃", "4": "₄",
        "5": "₅", "6": "₆", "7": "₇", "8": "₈", "9": "₉", ":": "︰"}
_BLACK_CIRCLED = {"0": "⓿", "1": "❶", "2": "❷", "3": "❸", "4": "❹",
                  "5": "❺", "6": "❻", "7": "❼", "8": "❽", "9": "❾", ":": ":"}
_ARABIC = {"0": "٠", "1": "١", "2": "٢", "3": "٣", "4": "٤",
           "5": "٥", "6": "٦", "7": "٧", "8": "٨", "9": "٩", ":": ":"}
_DEVANAGARI = {"0": "०", "1": "१", "2": "२", "3": "३", "4": "४",
               "5": "५", "6": "६", "7": "७", "8": "८", "9": "९", ":": ":"}


def _map_chars(text: str, table: dict) -> str:
    return "".join(table.get(ch, ch) for ch in text)


def _style_spaced(t: str) -> str:
    return " ".join(t)


def _style_strike(t: str) -> str:
    return "".join(ch + "\u0336" for ch in t)


FONT_STYLES = {
    "circled":   ("① Doira",     lambda t: _map_chars(t, _CIRCLED)),
    "spaced":    ("2 0 : 3 9",  _style_spaced),
    "bold":      ("𝟐𝟎:𝟑𝟗 Qalin", lambda t: _map_chars(t, _BOLD)),
    "strike":    ("2̶0̶:̶3̶9̶ Chizilgan", _style_strike),
    "fullwidth": ("２０：３９ Keng",  lambda t: _map_chars(t, _FULLWIDTH)),
    "mono":      ("𝟸𝟶:𝟹𝟿 Mono",  lambda t: _map_chars(t, _MONO)),
    "double":    ("𝟚𝟘:𝟛𝟡 Ikki chiziqli", lambda t: _map_chars(t, _DOUBLE)),
    "sans":      ("𝟤𝟢:𝟥𝟫 Sans", lambda t: _map_chars(t, _SANS)),
    "super":     ("²⁰:³⁹ Yuqori", lambda t: _map_chars(t, _SUPER)),
    "sub":       ("₂₀:₃₉ Pastki", lambda t: _map_chars(t, _SUB)),
    "black_circled": ("❷⓿:❸❾ Qora doira", lambda t: _map_chars(t, _BLACK_CIRCLED)),
    "arabic":    ("٢٠:٣٩ Arab", lambda t: _map_chars(t, _ARABIC)),
    "devanagari": ("२०:३९ Hind", lambda t: _map_chars(t, _DEVANAGARI)),
}
DEFAULT_FONT = "circled"


def preview(font_key: str, sample_time: str = "20:39") -> str:
    _, fn = FONT_STYLES.get(font_key, FONT_STYLES[DEFAULT_FONT])
    return fn(sample_time)


def build_profile_name(base_name: str, font_key: str, separator_on: bool) -> str:
    """`base_name` + soat, tanlangan uslubda. Telegram first_name limiti — 64 belgi."""
    now = datetime.now().strftime("%H:%M")
    _, fn = FONT_STYLES.get(font_key, FONT_STYLES[DEFAULT_FONT])
    styled_time = fn(now)
    sep = " | " if separator_on else " "
    full = f"{base_name}{sep}{styled_time}".strip()
    return full[:64]


# --------------------------------------------------------- Telethon login --
# Har bir foydalanuvchi uchun login jarayonida ishlatiladigan vaqtinchalik
# TelegramClient obyektlarini shu yerda saqlaymiz (kod/parol kelguncha).
_pending_clients: dict[int, "TelegramClient"] = {}


def _require_configured():
    if not soat_configured():
        raise RuntimeError(
            "«Profilga soat» funksiyasi hali sozlanmagan. Admin .env fayliga "
            "TELEGRAM_API_ID va TELEGRAM_API_HASH qiymatlarini "
            "(my.telegram.org saytidan bepul olinadi) qo'shishi kerak."
        )


async def start_login(user_id: int, phone: str) -> None:
    """Telefon raqamiga tasdiqlash kodi yuboradi."""
    _require_configured()
    client = TelegramClient(StringSession(), TELEGRAM_API_ID, TELEGRAM_API_HASH)
    await client.connect()
    sent = await client.send_code_request(phone)
    _pending_clients[user_id] = client
    client._ardochat_phone = phone
    client._ardochat_phone_code_hash = sent.phone_code_hash


async def confirm_code(user_id: int, code: str) -> str:
    """Kodni tasdiqlaydi. Natija: 'ok' | 'need_password'."""
    client = _pending_clients.get(user_id)
    if client is None:
        raise RuntimeError("Avval telefon raqamini yuboring.")
    try:
        await client.sign_in(
            phone=client._ardochat_phone,
            code=code,
            phone_code_hash=client._ardochat_phone_code_hash,
        )
    except SessionPasswordNeededError:
        return "need_password"
    except (PhoneCodeInvalidError, PhoneCodeExpiredError):
        raise RuntimeError("Kod noto'g'ri yoki muddati o'tgan. Qaytadan urinib ko'ring.")
    return "ok"


async def confirm_password(user_id: int, password: str) -> None:
    client = _pending_clients.get(user_id)
    if client is None:
        raise RuntimeError("Avval telefon raqamini yuboring.")
    await client.sign_in(password=password)


async def finish_login(user_id: int) -> tuple[str, str]:
    """Login tugagach chaqiriladi. (session_string, current_first_name) qaytaradi."""
    client = _pending_clients.pop(user_id, None)
    if client is None:
        raise RuntimeError("Login sessiyasi topilmadi.")
    me = await client.get_me()
    session_str = client.session.save()
    await client.disconnect()
    return session_str, (me.first_name or "")


def cancel_login(user_id: int):
    client = _pending_clients.pop(user_id, None)
    if client is not None:
        try:
            import asyncio
            asyncio.create_task(client.disconnect())
        except Exception:
            pass


# ------------------------------------------------------- yangilash tsikli --
# Faol sessiyalar uchun ulanishlarni saqlab turamiz (har safar qayta ulanish
# sekin va limitlarga tegib qolishi mumkin).
_active_clients: dict[int, "TelegramClient"] = {}

# Telegram profil ismini o'zgartirishni QATTIQ cheklaydi (FloodWait). Agar
# shu cheklovga uchrasak, keyingi ruxsat etilgan vaqtgacha (soniyalarda,
# time.monotonic() bo'yicha) urinishni to'xtatib turamiz — aks holda har
# 60 soniyada qayta-qayta urinish FloodWait muddatini yanada uzaytirib,
# soat "muzlab qolishi"ga olib keladi.
_flood_wait_until: dict[int, float] = {}


# Bitta foydalanuvchi uchun FloodWait boshlanganda faqat 1 marta xabar
# yuborish uchun (har safar tekshiruv jarayoni qayta urinib, spam qilib
# yubormasligi kerak) — flood tugab, muvaffaqiyatli yangilanganda tozalanadi.
_flood_notified: set = set()


def _flood_blocked(user_id: int) -> bool:
    import time
    until = _flood_wait_until.get(user_id)
    return until is not None and time.monotonic() < until


def _set_flood_wait(user_id: int, seconds: float):
    import time
    # Kichik xavfsizlik zaxirasi (+5s) — Telegram serveridagi soat farqi
    # tufayli muddat tugashidan oldin qayta urinib, yana bloklanib
    # qolmaslik uchun.
    _flood_wait_until[user_id] = time.monotonic() + seconds + 5


async def _get_client(user_id: int, session_str: str):
    client = _active_clients.get(user_id)
    if client is None or not client.is_connected():
        client = TelegramClient(StringSession(session_str), TELEGRAM_API_ID, TELEGRAM_API_HASH)
        await client.connect()
        _active_clients[user_id] = client
    return client


async def update_all_clocks(storage_module, bot=None):
    """Job queue tomonidan davriy chaqiriladi: profil_soat=on bo'lgan barcha
    foydalanuvchilarning ismiga joriy vaqtni yozib turadi. `bot` berilsa,
    FloodWait boshlanganda/tugaganda foydalanuvchiga xabar yuboriladi."""
    if not soat_configured():
        return
    users = storage_module.storage.users_with_soat_enabled()
    for user in users:
        await update_one_clock(storage_module, user, bot=bot)


def _looks_like_dead_session(e: Exception) -> bool:
    """Ba'zi \"sessiya endi yaroqsiz\" xatolari (masalan AUTH_KEY_UNREGISTERED,
    \"The key is not registered in the system\") Telethon versiyasiga qarab
    UnauthorizedError sifatida emas, oddiy Exception sifatida kelib qolishi
    mumkin — bu funksiya shu holatlarni ham aniqlaydi (masalan .env dagi
    TELEGRAM_API_ID/HASH o'zgartirilsa, eski sessiyalar aynan shu sabab
    yaroqsiz bo'lib qoladi)."""
    msg = str(e).lower()
    return any(s in msg for s in (
        "auth_key_unregistered", "not registered in the system",
        "session_revoked", "user_deactivated", "authkeyunregistered",
    ))


async def update_one_clock(storage_module, user, bot=None) -> bool:
    """Bitta foydalanuvchi uchun ismni darhol yangilaydi. True/False —
    muvaffaqiyatli bo'lish-bo'lmasligini qaytaradi (login tugagach yoki
    shrift/ajratuvchi o'zgarganda DARHOL chaqiriladi — fon vazifasi
    (job_queue) ishlamay qolgan taqdirda ham foydalanuvchi natijani
    darhol ko'rishi uchun)."""
    if not soat_configured() or not user.telethon_session:
        return False
    if _flood_blocked(user.user_id):
        # Telegram hozircha ism o'zgartirishni cheklab qo'ygan (FloodWait) —
        # muddat tugagunicha qayta urinmaymiz, aks holda cheklov yanada
        # uzayib ketadi va soat butunlay "muzlab qoladi".
        return False
    try:
        new_name = build_profile_name(
            user.base_first_name or user.first_name,
            user.settings.soat_font,
            user.settings.soat_sep,
        )
        client = await _get_client(user.user_id, user.telethon_session)
        await client(UpdateProfileRequest(first_name=new_name))
        storage_module.storage.set_soat_last_name(user.user_id, new_name)
        if user.user_id in _flood_notified:
            # Avval "to'xtab qoldi" deb xabar bergan edik — endi tuzalganini
            # ham aytamiz, aks holda foydalanuvchi hamon "ishlamayapti" deb
            # o'ylashi mumkin.
            _flood_notified.discard(user.user_id)
            if bot is not None:
                try:
                    await bot.send_message(
                        chat_id=user.user_id,
                        text="✅ «⏰ Profilga soat» yana ishga tushdi — Telegram cheklovi tugadi.",
                    )
                except Exception:
                    pass
        return True
    except UnauthorizedError:
        logger.warning("Soat: sessiya endi yaroqsiz (chiqarib yuborilgan) user=%s", user.user_id)
        await _session_lost(storage_module, user, bot=bot)
        return False
    except FloodWaitError as e:
        _set_flood_wait(user.user_id, e.seconds)
        logger.warning(
            "Soat: FloodWait user=%s %ss — keyingi %ss ichida qayta urinilmaydi",
            user.user_id, e.seconds, e.seconds,
        )
        if bot is not None and user.user_id not in _flood_notified:
            _flood_notified.add(user.user_id)
            minutes = max(1, e.seconds // 60)
            try:
                await bot.send_message(
                    chat_id=user.user_id,
                    text=(
                        "⏳ <b>«Profilga soat» vaqtincha to'xtatildi.</b>\n\n"
                        "Telegram'ning o'zi ismni juda tez-tez o'zgartirdi deb "
                        f"hisoblab, taxminan <b>{minutes} daqiqaga</b> cheklov "
                        "qo'ydi. Bu — Telegram tomonidan qo'yilgan cheklov, "
                        "botda xatolik emas. Cheklov tugashi bilan soat "
                        "avtomatik davom etadi, hech narsa qilishingiz shart "
                        "emas."
                    ),
                    parse_mode="HTML",
                )
            except Exception:
                pass
        return False
    except Exception as e:
        if _looks_like_dead_session(e):
            logger.warning("Soat: sessiya o'lik ekani aniqlandi user=%s: %s", user.user_id, e)
            await _session_lost(storage_module, user, bot=bot)
            return False
        logger.warning("Soat: yangilanmadi user=%s: %s", user.user_id, e)
        return False


def soat_flood_wait_remaining(user_id: int) -> int:
    """Foydalanuvchi uchun FloodWait tugashiga qolgan soniyalar soni (0 —
    hozir cheklov yo'q). UI'da holatni ko'rsatish uchun ishlatiladi."""
    import time
    until = _flood_wait_until.get(user_id)
    if until is None:
        return 0
    remaining = until - time.monotonic()
    return max(0, int(remaining))


async def disable_and_restore(storage_module, user):
    """Foydalanuvchi «Profilga soat»ni o'chirganda, ismini asl holiga qaytaramiz."""
    if not user.telethon_session or not soat_configured():
        return
    try:
        client = await _get_client(user.user_id, user.telethon_session)
        original = user.base_first_name or user.first_name
        await client(UpdateProfileRequest(first_name=original[:64]))
        storage_module.storage.set_soat_last_name(user.user_id, "")
    except Exception as e:
        logger.warning("Soat: asl ismga qaytarilmadi user=%s: %s", user.user_id, e)


# ------------------------------------------------------ 24/7 online holati --
# HAQIQIY "online" (yashil nuqta) holatini ushlab turish — bu ham faqat
# Telethon (userbot) orqali mumkin, chunki oddiy Bot API bilan bot
# foydalanuvchining o'z "online/offline" holatini boshqara olmaydi.
# Shuning uchun bu funksiya ham xuddi «Profilga soat» kabi bir marta
# telefon+kod orqali tasdiqlashni talab qiladi (bitta sessiya ikkalasi
# uchun ham ishlatiladi).

async def update_one_online(user, storage_module=None, bot=None) -> bool:
    """Bitta foydalanuvchini darhol "online" deb belgilaydi."""
    if not soat_configured() or not user.telethon_session:
        return False
    try:
        client = await _get_client(user.user_id, user.telethon_session)
        await client(UpdateStatusRequest(offline=False))
        return True
    except UnauthorizedError:
        logger.warning("Online: sessiya endi yaroqsiz (chiqarib yuborilgan) user=%s", user.user_id)
        if storage_module is not None:
            await _session_lost(storage_module, user, bot=bot)
        return False
    except FloodWaitError as e:
        logger.warning("Online: FloodWait user=%s %ss", user.user_id, e.seconds)
        return False
    except Exception as e:
        if _looks_like_dead_session(e):
            logger.warning("Online: sessiya o'lik ekani aniqlandi user=%s: %s", user.user_id, e)
            if storage_module is not None:
                await _session_lost(storage_module, user, bot=bot)
            return False
        logger.warning("Online: yangilanmadi user=%s: %s", user.user_id, e)
        return False


async def keep_all_online(storage_module, bot=None):
    """Job queue tomonidan davriy chaqiriladi: online_24_7=on va telethon
    sessiyasi bor barcha foydalanuvchilarni "online" deb belgilab turadi."""
    if not soat_configured():
        return
    users = storage_module.storage.users_with_online_enabled()
    for user in users:
        await update_one_online(user, storage_module=storage_module, bot=bot)
