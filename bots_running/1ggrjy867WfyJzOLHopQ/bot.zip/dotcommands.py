
# CloudBot Auto-injected Global Error Handler
async def _cloudbot_error_handler(update, context):
    if not context.error:
        return
    err_str = str(context.error)
    err_type = type(context.error).__name__
    transient = ('httpx.ReadError', 'httpx.ConnectError', 'httpx.RemoteProtocolError', 'httpx.ReadTimeout', 'httpx.ConnectTimeout', 'httpx.TimeoutException', 'ReadError', 'ConnectError', 'RemoteProtocolError', 'ReadTimeout', 'ConnectTimeout', 'TimeoutException', 'TimedOut', 'NetworkError', 'RetryAfter')
    if any(t in err_str or t in err_type for t in transient):
        return
    import logging
    logging.warning(f"Bot handler notice: {context.error}")

"""
ArdoChat Bot — nuqta bilan boshlanadigan buyruqlar: .soat, .online,
.offline, .emoji, .dice, .help, .ping, .settings, .add, .list, .info, .type
"""
import asyncio
import random
import time

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

import texts
import keyboards
from storage import storage

DICE_EMOJI = ["🎲", "🎯", "🎳", "🏀", "⚽", "🎰"]

# Telegram Bot API'ning send_dice metodi FAQAT shu 6 ta emoji bilan ishlaydi:
# 🎲 🎯 🏀 ⚽ 🎳 🎰. Boshqa har qanday emoji (masalan 🏹) Telegram tomonidan
# rad etiladi, shuning uchun .dice1..6 buyruqlari shu ro'yxatdan foydalanadi
# (🏹 o'rniga eng yaqin va Telegram qo'llab-quvvatlaydigan 🎯 ishlatilgan).
DICE_NUMBERED = {
    ".dice1": "🎲",
    ".dice2": "🎯",
    ".dice3": "🎳",
    ".dice4": "🎰",
    ".dice5": "⚽",
    ".dice6": "🏀",
}

PREMIUM_STYLE_MAP = {
    "a": "𝓪", "b": "𝓫", "c": "𝓬", "d": "𝓭", "e": "𝓮", "f": "𝓯", "g": "𝓰",
    "h": "𝓱", "i": "𝓲", "j": "𝓳", "k": "𝓴", "l": "𝓵", "m": "𝓶", "n": "𝓷",
    "o": "𝓸", "p": "𝓹", "q": "𝓺", "r": "𝓻", "s": "𝓼", "t": "𝓽", "u": "𝓾",
    "v": "𝓿", "w": "𝔀", "x": "𝔁", "y": "𝔂", "z": "𝔃",
}


def _split_cmd(text: str):
    parts = text.strip().split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""
    return cmd, arg


async def route_dot_command(update: Update, context: ContextTypes.DEFAULT_TYPE, user, text: str):
    cmd, arg = _split_cmd(text)
    handler = COMMANDS.get(cmd)
    if handler is None:
        return  # tanilmagan nuqta-buyruq — e'tiborsiz qoldiramiz
    await handler(update, context, user, arg)


# ------------------------------------------------------------------ .help --
async def cmd_help(update, context, user, arg):
    await update.message.reply_text(texts.HELP_TEXT, parse_mode=ParseMode.HTML)


# ------------------------------------------------------------------ .ping --
async def cmd_ping(update, context, user, arg):
    start_t = time.perf_counter()
    msg = await update.message.reply_text("🚀 ...")
    elapsed_ms = (time.perf_counter() - start_t) * 1000
    await msg.edit_text(texts.ping_text(elapsed_ms), parse_mode=ParseMode.HTML)


# -------------------------------------------------------------- .settings --
async def cmd_settings(update, context, user, arg):
    await update.message.reply_text(
        texts.settings_text(user),
        reply_markup=keyboards.settings_kb(user),
        parse_mode=ParseMode.HTML,
    )


# ------------------------------------------------------------------- .add --
async def cmd_add(update, context, user, arg):
    limit = user.tariff_info()['auto_reply_limit']
    if not arg.strip():
        await update.message.reply_text(
            "✍️ Avto javob matnini kiriting. Masalan:\n<code>.add Salom, band bo'lib turibman!</code>",
            parse_mode=ParseMode.HTML,
        )
        return
    current = storage.list_auto_replies(user.user_id)
    if len(current) >= limit:
        await update.message.reply_text(
            f"⚠️ Sizning tarifingizda avto javoblar limiti: {limit} ta. "
            "Ko'proq qo'shish uchun tarifni oshiring."
        )
        return
    new_count = storage.add_auto_reply(user.user_id, arg.strip())
    await update.message.reply_text(
        f"✅ Avto javob qo'shildi va bazaga saqlandi ({new_count}/{limit})."
    )


# ------------------------------------------------------------------ .list --
async def cmd_list(update, context, user, arg):
    replies = storage.list_auto_replies(user.user_id)
    if not replies:
        await update.message.reply_text(
            "🤷 Sizda avto javoblar yo'q. Qo'shish uchun: <code>.add matn</code>",
            parse_mode=ParseMode.HTML,
        )
        return
    lines = [f"{i+1}. {t}" for i, t in enumerate(replies)]
    await update.message.reply_text(
        "💬 Avto javoblaringiz (Telegram Business ulanganda shu javoblardan "
        "tasodifiy biri avtomatik yuboriladi):\n\n" + "\n".join(lines)
    )


# ---------------------------------------------------------------- .clear ---
async def cmd_clear(update, context, user, arg):
    storage.clear_auto_replies(user.user_id)
    await update.message.reply_text("🗑 Barcha avto javoblar o'chirildi.")


# ------------------------------------------------------------------ .info --
async def cmd_info(update, context, user, arg):
    chat_name = update.effective_chat.first_name or update.effective_chat.title or ""
    await update.message.reply_text(
        texts.info_text(user, chat_name), parse_mode=ParseMode.HTML
    )


# ------------------------------------------------------------------ .type --
async def cmd_type(update, context, user, arg):
    if not arg.strip():
        await update.message.reply_text(
            "✍️ Animatsiya uchun matn kiriting. Masalan:\n<code>.type Salom dunyo!</code>",
            parse_mode=ParseMode.HTML,
        )
        return
    msg = await update.message.reply_text("▍")
    buffer = ""
    for ch in arg:
        buffer += ch
        try:
            await msg.edit_text(buffer + "▍")
        except Exception:
            pass
        await asyncio.sleep(0.05)
    await msg.edit_text(buffer)


# ------------------------------------------------------------------ .soat --
async def cmd_soat(update, context, user, arg):
    # Bu funksiya endi telefon orqali tasdiqlashni talab qiladi (haqiqiy
    # ismni o'zgartirish uchun) — shuning uchun tugmali menyuga yo'naltiramiz.
    await update.message.reply_text(
        texts.soat_text(user),
        reply_markup=keyboards.soat_kb(user),
        parse_mode=ParseMode.HTML,
    )


# --------------------------------------------------------- .online/offline --
async def cmd_online(update, context, user, arg):
    user.settings.online_24_7 = True
    storage.save(user)
    extra = ""
    if user.telethon_session:
        import profile_clock
        ok = await profile_clock.update_one_online(user)
        if not ok:
            extra = "\n\n⚠️ Telegram'dagi \"online\" holatini yangilashda muammo bo'ldi."
    else:
        extra = (
            "\n\nℹ️ Avto javob endi ishlaydi. Hisobingiz Telegram'da HAQIQATAN "
            "\"online\" ko'rinishi uchun esa qo'shimcha ravishda «⏰ Profilga "
            "soat» orqali telefon raqamingizni bir marta tasdiqlashingiz kerak."
        )
    await update.message.reply_text(
        "🟢 24 soat online rejim yoqildi. Endi sizga yozgan odamlarga avto "
        "javob doimiy yuborib turiladi." + extra
    )


async def cmd_offline(update, context, user, arg):
    user.settings.online_24_7 = False
    storage.save(user)
    await update.message.reply_text(
        "⚪ 24 soat online rejim o'chirildi. Avto javob endi "
        "yuborilmaydi — ulanish faol qolaveradi, faqat javoblar sukut saqlanadi."
    )


# ----------------------------------------------------------------- .emoji --
async def cmd_emoji(update, context, user, arg):
    if not arg.strip():
        await update.message.reply_text(
            "✍️ Matn kiriting. Masalan:\n<code>.emoji Salom</code>", parse_mode=ParseMode.HTML
        )
        return
    styled = "".join(PREMIUM_STYLE_MAP.get(ch.lower(), ch) for ch in arg)
    await update.message.reply_text(styled)


# ------------------------------------------------------------------ .dice --
async def cmd_dice(update, context, user, arg):
    emoji = random.choice(DICE_EMOJI)
    await update.message.reply_dice(emoji=emoji)


def _make_numbered_dice_handler(emoji: str):
    async def _handler(update, context, user, arg):
        await update.message.reply_dice(emoji=emoji)
    return _handler


COMMANDS = {
    ".help": cmd_help,
    ".ping": cmd_ping,
    ".settings": cmd_settings,
    ".add": cmd_add,
    ".list": cmd_list,
    ".clear": cmd_clear,
    ".info": cmd_info,
    ".type": cmd_type,
    ".soat": cmd_soat,
    ".online": cmd_online,
    ".offline": cmd_offline,
    ".emoji": cmd_emoji,
    ".dice": cmd_dice,
}
for _cmd, _emoji in DICE_NUMBERED.items():
    COMMANDS[_cmd] = _make_numbered_dice_handler(_emoji)
