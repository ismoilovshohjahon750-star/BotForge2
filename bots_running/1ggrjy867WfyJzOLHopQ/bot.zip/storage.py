"""
ArdoChat Bot — SQLite orqali DOIMIY saqlash.

Nega SQLite, JSON emas: talab bo'yicha JSON fayllar ishlatilmaydi, lekin
"1000% ishlaydigan" bot uchun ma'lumotlar bot qayta ishga tushirilganda
yo'qolmasligi kerak. SQLite — Python standart kutubxonasining bir qismi
(tashqi server kerak emas, bitta .db fayl), shuning uchun eng mos yechim.
"""
import sqlite3
import threading
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional

from config import TARIFFS, DB_PATH

_lock = threading.RLock()
_conn = sqlite3.connect(DB_PATH, check_same_thread=False)
_conn.row_factory = sqlite3.Row


def _init_db():
    with _lock, _conn:
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                first_name TEXT DEFAULT '',
                tariff TEXT DEFAULT 'free',
                tariff_until TEXT,
                balance_som INTEGER DEFAULT 0,
                balance_stars INTEGER DEFAULT 0,
                referrals INTEGER DEFAULT 0,
                referred_by INTEGER,
                ai_daily_used INTEGER DEFAULT 0,
                ai_daily_date TEXT DEFAULT '',
                profil_soat INTEGER DEFAULT 0,
                online_24_7 INTEGER DEFAULT 0,
                ok_text TEXT DEFAULT 'Band, tez orada javob beraman.',
                loc_text TEXT DEFAULT '',
                ai_prompt TEXT DEFAULT 'Dostona va qisqa javob ber.',
                ai_type TEXT DEFAULT 'ChatGPT',
                ai_for_all INTEGER DEFAULT 0,
                business_connection_id TEXT,
                created_at TEXT DEFAULT '',
                telethon_session TEXT,
                base_first_name TEXT DEFAULT '',
                soat_font TEXT DEFAULT 'circled',
                soat_sep INTEGER DEFAULT 1,
                soat_last_name TEXT DEFAULT '',
                spy_mode INTEGER DEFAULT 0,
                edit_notify INTEGER DEFAULT 0,
                edit_notify_text TEXT DEFAULT '❓ Nega bu xabarni tahrirladingiz?',
                delete_notify INTEGER DEFAULT 0,
                delete_notify_text TEXT DEFAULT '❓ Nega boyagi xabarni o''chirdingiz?',
                apk_autodelete INTEGER DEFAULT 0,
                typing_notify INTEGER DEFAULT 0,
                is_banned INTEGER DEFAULT 0,
                autoreply_mode TEXT DEFAULT 'once',
                work_hours_enabled INTEGER DEFAULT 0,
                work_hours_start TEXT DEFAULT '09:00',
                work_hours_end TEXT DEFAULT '18:00',
                after_hours_text TEXT DEFAULT ''
            )
        """)
        _existing_cols = {r['name'] for r in _conn.execute("PRAGMA table_info(users)")}
        _new_cols = {
            "telethon_session": "TEXT",
            "base_first_name": "TEXT DEFAULT ''",
            "soat_font": "TEXT DEFAULT 'circled'",
            "soat_sep": "INTEGER DEFAULT 1",
            "soat_last_name": "TEXT DEFAULT ''",
            "spy_mode": "INTEGER DEFAULT 0",
            "edit_notify": "INTEGER DEFAULT 0",
            "edit_notify_text": "TEXT DEFAULT '❓ Nega bu xabarni tahrirladingiz?'",
            "delete_notify": "INTEGER DEFAULT 0",
            "delete_notify_text": "TEXT DEFAULT '❓ Nega boyagi xabarni o''chirdingiz?'",
            "apk_autodelete": "INTEGER DEFAULT 0",
            "typing_notify": "INTEGER DEFAULT 0",
            "is_banned": "INTEGER DEFAULT 0",
            "autoreply_mode": "TEXT DEFAULT 'once'",
            "work_hours_enabled": "INTEGER DEFAULT 0",
            "work_hours_start": "TEXT DEFAULT '09:00'",
            "work_hours_end": "TEXT DEFAULT '18:00'",
            "after_hours_text": "TEXT DEFAULT ''",
        }
        for col, decl in _new_cols.items():
            if col not in _existing_cols:
                _conn.execute(f"ALTER TABLE users ADD COLUMN {col} {decl}")
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS auto_replies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                text TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(user_id)
            )
        """)
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS topups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                method TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT '',
                pay_amount INTEGER
            )
        """)
        _existing_topup_cols = {r['name'] for r in _conn.execute("PRAGMA table_info(topups)")}
        if "pay_amount" not in _existing_topup_cols:
            _conn.execute("ALTER TABLE topups ADD COLUMN pay_amount INTEGER")
        # 📲 SMS orqali avtomatik to'lovni aniqlash: adminning (bank SMS'lari
        # kelib turadigan) shaxsiy Telegram akkountiga Telethon (userbot)
        # orqali ulanish uchun sessiya shu yerda saqlanadi. Bu — «Profilga
        # soat»dagi bilan bir xil texnik asos (telefon + kod orqali login),
        # lekin alohida jadval: chunki bu odatda BOShqA (masalan bankka
        # bog'langan SIM kartaning) akkounti bo'lishi mumkin, admin
        # o'zining shaxsiy botdagi profilidan mustaqil ravishda ulaydi.
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS sms_accounts (
                admin_id INTEGER PRIMARY KEY,
                session TEXT,
                enabled INTEGER DEFAULT 0,
                sender_filter TEXT DEFAULT '',
                created_at TEXT DEFAULT ''
            )
        """)
        _conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_business_conn ON users(business_connection_id)"
        )
        # Har bir (egasi, suhbat) juftligi uchun avto-javob allaqachon
        # yuborilganini eslab qolish uchun — "faqat 1 marta" rejimi shu
        # jadval orqali ISHLAYDI va bot qayta ishga tushirilsa ham yo'qolmaydi
        # (avvalgi versiyada bu faqat xotirada, vaqtinchalik saqlanardi).
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS autoreply_sent (
                owner_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                sent_at TEXT DEFAULT '',
                PRIMARY KEY (owner_id, chat_id)
            )
        """)
        # 👥 Mijozlar: har bir biznes-egasi uchun suhbatdoshlar ro'yxati —
        # teg/izoh qo'yish va oxirgi yozishmalarni ko'rish uchun.
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS contacts (
                owner_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                name TEXT DEFAULT '',
                tag TEXT DEFAULT '',
                note TEXT DEFAULT '',
                message_count INTEGER DEFAULT 0,
                first_seen TEXT DEFAULT '',
                last_seen TEXT DEFAULT '',
                PRIMARY KEY (owner_id, chat_id)
            )
        """)
        # 🔑 Kalit so'zga qarab avto-javob: suhbatdosh xabarida shu so'z
        # uchrasa, umumiy avto-javob o'rniga shu maxsus javob yuboriladi.
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS keyword_replies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id INTEGER NOT NULL,
                keyword TEXT NOT NULL,
                reply_text TEXT NOT NULL
            )
        """)
        # 🧾 Admin harakatlari logi (bloklash, balans qo'shish va h.k.)
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS admin_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT DEFAULT '',
                action TEXT NOT NULL,
                target_id INTEGER,
                detail TEXT DEFAULT ''
            )
        """)
        # 🎨 Premium emoji: oddiy emoji belgisi -> admin bergan premium
        # custom_emoji_id. Botning barcha MATNLARIDA (tugmalarda EMAS —
        # Telegram bot tugmalari umuman rasmiylashtirilgan matnni qo'llab-
        # quvvatlamaydi) shu emoji uchraganda, premium ko'rinishda chiqadi.
        _conn.execute("""
            CREATE TABLE IF NOT EXISTS premium_emoji_map (
                emoji_char TEXT PRIMARY KEY,
                custom_emoji_id TEXT NOT NULL,
                updated_at TEXT DEFAULT ''
            )
        """)


_init_db()


@dataclass
class UserSettings:
    profil_soat: bool = False
    online_24_7: bool = False
    ok_text: str = "Band, tez orada javob beraman."
    loc_text: str = ""
    ai_prompt: str = "Do'stona va qisqa javob ber."
    ai_type: str = "ChatGPT"
    ai_for_all: bool = False
    soat_font: str = "circled"
    soat_sep: bool = True
    spy_mode: bool = False
    edit_notify: bool = False
    edit_notify_text: str = "❓ Nega bu xabarni tahrirladingiz?"
    delete_notify: bool = False
    delete_notify_text: str = "❓ Nega boyagi xabarni o'chirdingiz?"
    apk_autodelete: bool = False
    typing_notify: bool = False
    # "once"  — har bir suhbatdoshga FAQAT bitta marta avto-javob yuboriladi,
    #           keyin u yana yozsa ham jim turadi (standart holat).
    # "always" — suhbatdosh har safar yozganda avto-javob yuboraveradi.
    autoreply_mode: str = "once"
    # ⏰ Ish vaqti bo'yicha avto-javob: yoqilgan bo'lsa, faqat shu oraliqda
    # oddiy avto-javob yuboriladi, undan tashqarida `after_hours_text`
    # (agar bo'sh bo'lmasa) yuboriladi.
    work_hours_enabled: bool = False
    work_hours_start: str = "09:00"
    work_hours_end: str = "18:00"
    after_hours_text: str = ""


@dataclass
class UserData:
    user_id: int
    first_name: str = ""
    tariff: str = "free"
    tariff_until: Optional[datetime] = None
    balance_som: int = 0
    balance_stars: int = 0
    referrals: int = 0
    referred_by: Optional[int] = None
    auto_replies: List[str] = field(default_factory=list)
    ai_daily_used: int = 0
    ai_daily_date: str = ""
    settings: UserSettings = field(default_factory=UserSettings)
    business_connection_id: Optional[str] = None
    telethon_session: Optional[str] = None
    base_first_name: str = ""
    soat_last_name: str = ""
    is_banned: bool = False

    def tariff_info(self):
        return TARIFFS.get(self.tariff, TARIFFS["free"])

    @property
    def is_pro(self) -> bool:
        """Pro tarif faol va muddati o'tmaganmi. Muddatsiz (tariff_until=None)
        bo'lsa ham 'pro' bo'lsa faol hisoblanadi (masalan admin qo'lda bergan)."""
        if self.tariff != "pro":
            return False
        if self.tariff_until is None:
            return True
        return self.tariff_until >= datetime.now()

    def has_feature(self, key: str) -> bool:
        """Masalan: user.has_feature('soat_enabled')."""
        if not self.tariff_info().get(key, False):
            return False
        if self.tariff == "pro":
            return self.is_pro
        return True

    def ensure_today_counter(self):
        today = datetime.now().strftime("%Y-%m-%d")
        if self.ai_daily_date != today:
            self.ai_daily_date = today
            self.ai_daily_used = 0

    @property
    def connected(self) -> bool:
        return bool(self.business_connection_id)


def _row_to_user(row: sqlite3.Row) -> UserData:
    tariff_until = None
    if row['tariff_until']:
        try:
            tariff_until = datetime.fromisoformat(row['tariff_until'])
        except ValueError:
            tariff_until = None

    settings = UserSettings(
        profil_soat=bool(row['profil_soat']),
        online_24_7=bool(row['online_24_7']),
        ok_text=row['ok_text'] or "",
        loc_text=row['loc_text'] or "",
        ai_prompt=row['ai_prompt'] or "",
        ai_type=row['ai_type'] or "ChatGPT",
        ai_for_all=bool(row['ai_for_all']),
        soat_font=row['soat_font'] or "circled",
        soat_sep=bool(row['soat_sep']) if row['soat_sep'] is not None else True,
        spy_mode=bool(row['spy_mode']) if "spy_mode" in row.keys() else False,
        edit_notify=bool(row['edit_notify']) if "edit_notify" in row.keys() else False,
        edit_notify_text=(row['edit_notify_text'] if "edit_notify_text" in row.keys() and row['edit_notify_text'] else "❓ Nega bu xabarni tahrirladingiz?"),
        delete_notify=bool(row['delete_notify']) if "delete_notify" in row.keys() else False,
        delete_notify_text=(row['delete_notify_text'] if "delete_notify_text" in row.keys() and row['delete_notify_text'] else "❓ Nega boyagi xabarni o'chirdingiz?"),
        apk_autodelete=bool(row['apk_autodelete']) if "apk_autodelete" in row.keys() else False,
        typing_notify=bool(row['typing_notify']) if "typing_notify" in row.keys() else False,
        autoreply_mode=(row['autoreply_mode'] if "autoreply_mode" in row.keys() and row['autoreply_mode'] else "once"),
        work_hours_enabled=bool(row['work_hours_enabled']) if "work_hours_enabled" in row.keys() else False,
        work_hours_start=(row['work_hours_start'] if "work_hours_start" in row.keys() and row['work_hours_start'] else "09:00"),
        work_hours_end=(row['work_hours_end'] if "work_hours_end" in row.keys() and row['work_hours_end'] else "18:00"),
        after_hours_text=(row['after_hours_text'] if "after_hours_text" in row.keys() else "") or "",
    )

    with _lock:
        replies = [
            r['text'] for r in _conn.execute(
                "SELECT text FROM auto_replies WHERE user_id = ? ORDER BY id", (row['user_id'],)
            )
        ]

    return UserData(
        user_id=row['user_id'],
        first_name=row['first_name'] or "",
        tariff=row['tariff'] or "free",
        tariff_until=tariff_until,
        balance_som=row['balance_som'] or 0,
        balance_stars=row['balance_stars'] or 0,
        referrals=row['referrals'] or 0,
        referred_by=row['referred_by'],
        auto_replies=replies,
        ai_daily_used=row['ai_daily_used'] or 0,
        ai_daily_date=row['ai_daily_date'] or "",
        settings=settings,
        business_connection_id=row['business_connection_id'],
        telethon_session=row['telethon_session'],
        base_first_name=row['base_first_name'] or "",
        soat_last_name=row['soat_last_name'] or "",
        is_banned=bool(row['is_banned']) if "is_banned" in row.keys() else False,
    )


class Storage:
    """SQLite ustidagi yupqa qatlam — barcha yozish/o'qish shu yerdan o'tadi."""

    def get(self, user_id: int, first_name: str = "") -> UserData:
        with _lock:
            row = _conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
            if row is None:
                with _conn:
                    _conn.execute(
                        "INSERT INTO users (user_id, first_name, created_at) VALUES (?, ?, ?)",
                        (user_id, first_name, datetime.now().isoformat()),
                    )
                row = _conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
            elif first_name and first_name != row['first_name']:
                with _conn:
                    _conn.execute(
                        "UPDATE users SET first_name = ? WHERE user_id = ?", (first_name, user_id)
                    )
                row = _conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
            return _row_to_user(row)

    def save(self, user: UserData):
        """Skalyar maydonlarni va sozlamalarni bazaga yozadi (auto_replies alohida)."""
        with _lock, _conn:
            _conn.execute(
                """UPDATE users SET
                    first_name = ?, tariff = ?, tariff_until = ?,
                    balance_som = ?, balance_stars = ?, referrals = ?, referred_by = ?,
                    ai_daily_used = ?, ai_daily_date = ?,
                    profil_soat = ?, online_24_7 = ?, ok_text = ?, loc_text = ?,
                    ai_prompt = ?, ai_type = ?, ai_for_all = ?, business_connection_id = ?,
                    base_first_name = ?, soat_font = ?, soat_sep = ?, soat_last_name = ?,
                    spy_mode = ?, edit_notify = ?, edit_notify_text = ?,
                    delete_notify = ?, delete_notify_text = ?, apk_autodelete = ?,
                    typing_notify = ?, is_banned = ?, autoreply_mode = ?,
                    work_hours_enabled = ?, work_hours_start = ?,
                    work_hours_end = ?, after_hours_text = ?
                   WHERE user_id = ?""",
                (
                    user.first_name, user.tariff,
                    user.tariff_until.isoformat() if user.tariff_until else None,
                    user.balance_som, user.balance_stars, user.referrals, user.referred_by,
                    user.ai_daily_used, user.ai_daily_date,
                    int(user.settings.profil_soat), int(user.settings.online_24_7),
                    user.settings.ok_text, user.settings.loc_text,
                    user.settings.ai_prompt, user.settings.ai_type, int(user.settings.ai_for_all),
                    user.business_connection_id,
                    user.base_first_name, user.settings.soat_font, int(user.settings.soat_sep),
                    user.soat_last_name, int(user.settings.spy_mode),
                    int(user.settings.edit_notify), user.settings.edit_notify_text,
                    int(user.settings.delete_notify), user.settings.delete_notify_text,
                    int(user.settings.apk_autodelete), int(user.settings.typing_notify),
                    int(user.is_banned), user.settings.autoreply_mode,
                    int(user.settings.work_hours_enabled), user.settings.work_hours_start,
                    user.settings.work_hours_end, user.settings.after_hours_text,
                    user.user_id,
                ),
            )

    def set_tariff(self, user_id: int, tariff: str, days: int = 30):
        user = self.get(user_id)
        user.tariff = tariff
        user.tariff_until = None if tariff == "free" else datetime.now() + timedelta(days=days)
        self.save(user)
        return user

    def give_pro(self, user_id: int, days: int = 30):
        user = self.get(user_id)
        base = (user.tariff_until if user.tariff == "pro" and user.tariff_until
                and user.tariff_until > datetime.now() else datetime.now())
        user.tariff = "pro"
        user.tariff_until = base + timedelta(days=days)
        self.save(user)
        return user

    def remove_pro(self, user_id: int):
        user = self.get(user_id)
        user.tariff = "free"
        user.tariff_until = None
        self.save(user)
        return user

    def add_balance_som(self, user_id: int, amount: int):
        with _lock, _conn:
            _conn.execute(
                "UPDATE users SET balance_som = balance_som + ? WHERE user_id = ?",
                (amount, user_id),
            )

    def add_balance_stars(self, user_id: int, amount: int):
        with _lock, _conn:
            _conn.execute(
                "UPDATE users SET balance_stars = balance_stars + ? WHERE user_id = ?",
                (amount, user_id),
            )

    def deduct_balance_som(self, user_id: int, amount: int) -> bool:
        with _lock, _conn:
            row = _conn.execute(
                "SELECT balance_som FROM users WHERE user_id = ?", (user_id,)
            ).fetchone()
            if row is None or row['balance_som'] < amount:
                return False
            _conn.execute(
                "UPDATE users SET balance_som = balance_som - ? WHERE user_id = ?",
                (amount, user_id),
            )
            return True

    def add_referral(self, referrer_id: int, new_user_id: int) -> bool:
        """Yangi foydalanuvchi kimdir taklifi bilan kirganda chaqiriladi.
        Har bir foydalanuvchi faqat bir marta hisoblanadi (referred_by orqali)."""
        with _lock:
            new_user_row = _conn.execute(
                "SELECT referred_by FROM users WHERE user_id = ?", (new_user_id,)
            ).fetchone()
            if new_user_row and new_user_row['referred_by']:
                return False
            if referrer_id == new_user_id:
                return False
            with _conn:
                _conn.execute(
                    "UPDATE users SET referred_by = ? WHERE user_id = ?",
                    (referrer_id, new_user_id),
                )
                _conn.execute(
                    "UPDATE users SET referrals = referrals + 1 WHERE user_id = ?",
                    (referrer_id,),
                )
            referrer = self.get(referrer_id)
            star_bonus = referrer.tariff_info()['referral_star']
            self.add_balance_stars(referrer_id, star_bonus)
            return True

    def find_existing(self, user_id: int) -> Optional['UserData']:
        """storage.get() dan farqi: foydalanuvchi bazada yo'q bo'lsa uni
        yaratib yubormaydi — faqat mavjud bo'lsa qaytaradi. Admin panelda
        foydalanuvchini qidirishda "yo'q" holatini to'g'ri aniqlash uchun."""
        with _lock:
            row = _conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
            return _row_to_user(row) if row else None

    def set_banned(self, user_id: int, banned: bool):
        with _lock, _conn:
            _conn.execute(
                "UPDATE users SET is_banned = ? WHERE user_id = ?", (int(banned), user_id)
            )

    def list_banned(self) -> List['UserData']:
        with _lock:
            rows = _conn.execute("SELECT * FROM users WHERE is_banned = 1").fetchall()
            return [_row_to_user(r) for r in rows]

    def list_banned_page(self, limit: int = 20, offset: int = 0) -> List['UserData']:
        """Bloklanganlar ro'yxatini sahifalab (limit+1 olib, keyingi sahifa
        borligini tekshirish uchun) qaytaradi."""
        with _lock:
            rows = _conn.execute(
                "SELECT * FROM users WHERE is_banned = 1 ORDER BY user_id LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()
            return [_row_to_user(r) for r in rows]

    # --------------------------------------------- avto-javob "1 marta" ---
    def has_autoreply_sent(self, owner_id: int, chat_id: int) -> bool:
        with _lock:
            row = _conn.execute(
                "SELECT 1 FROM autoreply_sent WHERE owner_id = ? AND chat_id = ?",
                (owner_id, chat_id),
            ).fetchone()
            return row is not None

    def mark_autoreply_sent(self, owner_id: int, chat_id: int):
        with _lock, _conn:
            _conn.execute(
                "INSERT OR REPLACE INTO autoreply_sent (owner_id, chat_id, sent_at) "
                "VALUES (?, ?, ?)",
                (owner_id, chat_id, datetime.now().isoformat()),
            )

    def reset_autoreply_sent(self, owner_id: int, chat_id: Optional[int] = None):
        """chat_id berilmasa — shu egaga tegishli BARCHA "yuborilgan" belgilarni
        tozalaydi (ya'ni "faqat 1 marta" rejimi hammaga qayta ishlaydi)."""
        with _lock, _conn:
            if chat_id is None:
                _conn.execute("DELETE FROM autoreply_sent WHERE owner_id = ?", (owner_id,))
            else:
                _conn.execute(
                    "DELETE FROM autoreply_sent WHERE owner_id = ? AND chat_id = ?",
                    (owner_id, chat_id),
                )

    def add_auto_reply(self, user_id: int, text: str) -> int:
        with _lock, _conn:
            _conn.execute(
                "INSERT INTO auto_replies (user_id, text) VALUES (?, ?)", (user_id, text)
            )
            count = _conn.execute(
                "SELECT COUNT(*) c FROM auto_replies WHERE user_id = ?", (user_id,)
            ).fetchone()['c']
            return count

    def list_auto_replies(self, user_id: int) -> List[str]:
        with _lock:
            return [
                r['text'] for r in _conn.execute(
                    "SELECT text FROM auto_replies WHERE user_id = ? ORDER BY id", (user_id,)
                )
            ]

    def clear_auto_replies(self, user_id: int):
        with _lock, _conn:
            _conn.execute("DELETE FROM auto_replies WHERE user_id = ?", (user_id,))

    def set_business_connection(self, user_id: int, connection_id: Optional[str]):
        with _lock, _conn:
            _conn.execute(
                "UPDATE users SET business_connection_id = ? WHERE user_id = ?",
                (connection_id, user_id),
            )

    def find_user_by_connection(self, connection_id: str) -> Optional[UserData]:
        with _lock:
            row = _conn.execute(
                "SELECT * FROM users WHERE business_connection_id = ?", (connection_id,)
            ).fetchone()
            return _row_to_user(row) if row else None

    def clear_connection_everywhere(self, connection_id: str):
        with _lock, _conn:
            _conn.execute(
                "UPDATE users SET business_connection_id = NULL WHERE business_connection_id = ?",
                (connection_id,),
            )

    def set_telethon_session(self, user_id: int, session_str: Optional[str]):
        with _lock, _conn:
            _conn.execute(
                "UPDATE users SET telethon_session = ? WHERE user_id = ?",
                (session_str, user_id),
            )

    def set_base_first_name(self, user_id: int, name: str):
        with _lock, _conn:
            _conn.execute(
                "UPDATE users SET base_first_name = ? WHERE user_id = ?", (name, user_id)
            )

    def set_soat_last_name(self, user_id: int, name: str):
        with _lock, _conn:
            _conn.execute(
                "UPDATE users SET soat_last_name = ? WHERE user_id = ?", (name, user_id)
            )

    def users_with_soat_enabled(self) -> List[UserData]:
        """«Profilga soat» yoqilgan va telethon sessiyasi mavjud foydalanuvchilar."""
        with _lock:
            rows = _conn.execute(
                "SELECT * FROM users WHERE profil_soat = 1 AND telethon_session IS NOT NULL "
                "AND telethon_session != '' AND tariff = 'pro'"
            ).fetchall()
            return [_row_to_user(r) for r in rows]

    def users_with_online_enabled(self) -> List[UserData]:
        """«24/7 online» yoqilgan va telethon sessiyasi mavjud foydalanuvchilar."""
        with _lock:
            rows = _conn.execute(
                "SELECT * FROM users WHERE online_24_7 = 1 AND telethon_session IS NOT NULL "
                "AND telethon_session != '' AND tariff = 'pro'"
            ).fetchall()
            return [_row_to_user(r) for r in rows]

    def users_with_spy_enabled(self) -> List[UserData]:
        """Shpion rejimi (shaxsiy akkaunt, Telethon orqali) yoqilgan va
        sessiyasi mavjud foydalanuvchilar — bot qayta ishga tushganda
        tinglovchilarni qayta ulash uchun ishlatiladi."""
        with _lock:
            rows = _conn.execute(
                "SELECT * FROM users WHERE spy_mode = 1 AND telethon_session IS NOT NULL "
                "AND telethon_session != '' AND tariff = 'pro'"
            ).fetchall()
            return [_row_to_user(r) for r in rows]

    def create_topup(self, user_id: int, amount: int, method: str, pay_amount: int = None) -> int:
        with _lock, _conn:
            cur = _conn.execute(
                "INSERT INTO topups (user_id, amount, method, created_at, pay_amount) VALUES (?, ?, ?, ?, ?)",
                (user_id, amount, method, datetime.now().isoformat(), pay_amount),
            )
            return cur.lastrowid

    def get_topup(self, topup_id: int):
        with _lock:
            return _conn.execute("SELECT * FROM topups WHERE id = ?", (topup_id,)).fetchone()

    def set_topup_status(self, topup_id: int, status: str):
        with _lock, _conn:
            _conn.execute("UPDATE topups SET status = ? WHERE id = ?", (status, topup_id))

    def list_pending_topups(self) -> List[sqlite3.Row]:
        with _lock:
            return _conn.execute(
                "SELECT * FROM topups WHERE status = 'pending' ORDER BY id DESC"
            ).fetchall()

    def pending_pay_amounts(self, method: str = "card") -> List[int]:
        """Hozir kutilayotgan barcha (hali to'lanmagan) so'rovlarning
        \"aynan shu summani o'tkazing\" summalari — yangi so'rov uchun
        summa tanlaganda ular bilan TO'QNASHMAYDIGAN qiymat tanlash uchun."""
        with _lock:
            rows = _conn.execute(
                "SELECT pay_amount FROM topups WHERE status = 'pending' AND method = ? "
                "AND pay_amount IS NOT NULL",
                (method,),
            ).fetchall()
            return [r['pay_amount'] for r in rows]

    def find_pending_topup_by_pay_amount(self, pay_amount: int, method: str = "card"):
        """SMS orqali kelgan summaga mos, hali tasdiqlanmagan so'rovni topadi.
        Bir nechtasi mos kelsa — eng eskisini (birinchi navbatda yaratilganini)
        qaytaradi."""
        with _lock:
            return _conn.execute(
                "SELECT * FROM topups WHERE status = 'pending' AND method = ? "
                "AND pay_amount = ? ORDER BY id ASC LIMIT 1",
                (method, pay_amount),
            ).fetchone()

    # --------------------------------------------------- SMS to'lov akkaunti --
    def get_sms_account(self, admin_id: int):
        with _lock:
            return _conn.execute(
                "SELECT * FROM sms_accounts WHERE admin_id = ?", (admin_id,)
            ).fetchone()

    def set_sms_session(self, admin_id: int, session: str):
        with _lock, _conn:
            _conn.execute(
                "INSERT INTO sms_accounts (admin_id, session, enabled, created_at) "
                "VALUES (?, ?, 1, ?) "
                "ON CONFLICT(admin_id) DO UPDATE SET session = excluded.session, enabled = 1",
                (admin_id, session, datetime.now().isoformat()),
            )

    def set_sms_enabled(self, admin_id: int, enabled: bool):
        with _lock, _conn:
            _conn.execute(
                "UPDATE sms_accounts SET enabled = ? WHERE admin_id = ?",
                (1 if enabled else 0, admin_id),
            )

    def clear_sms_session(self, admin_id: int):
        with _lock, _conn:
            _conn.execute(
                "UPDATE sms_accounts SET session = NULL, enabled = 0 WHERE admin_id = ?",
                (admin_id,),
            )

    def set_sms_sender_filter(self, admin_id: int, sender_filter: str):
        with _lock, _conn:
            _conn.execute(
                "UPDATE sms_accounts SET sender_filter = ? WHERE admin_id = ?",
                (sender_filter, admin_id),
            )

    def all_enabled_sms_accounts(self) -> List[sqlite3.Row]:
        with _lock:
            return _conn.execute(
                "SELECT * FROM sms_accounts WHERE enabled = 1 AND session IS NOT NULL AND session != ''"
            ).fetchall()

    def all_user_ids(self) -> List[int]:
        with _lock:
            return [r['user_id'] for r in _conn.execute("SELECT user_id FROM users")]

    def stats(self):
        with _lock:
            total = _conn.execute("SELECT COUNT(*) c FROM users").fetchone()['c']
            connected = _conn.execute(
                "SELECT COUNT(*) c FROM users WHERE business_connection_id IS NOT NULL"
            ).fetchone()['c']
            online = _conn.execute(
                "SELECT COUNT(*) c FROM users WHERE online_24_7 = 1"
            ).fetchone()['c']
            banned = _conn.execute(
                "SELECT COUNT(*) c FROM users WHERE is_banned = 1"
            ).fetchone()['c']
            balance_sum = _conn.execute(
                "SELECT COALESCE(SUM(balance_som), 0) s FROM users"
            ).fetchone()['s']
            autoreply_count = _conn.execute(
                "SELECT COUNT(*) c FROM auto_replies"
            ).fetchone()['c']
            pending_topups = _conn.execute(
                "SELECT COUNT(*) c FROM topups WHERE status = 'pending'"
            ).fetchone()['c']
            by_tariff = {
                r['tariff']: r['c'] for r in _conn.execute(
                    "SELECT tariff, COUNT(*) c FROM users GROUP BY tariff"
                )
            }
            return {
                "total": total,
                "connected": connected,
                "online": online,
                "banned": banned,
                "balance_sum": balance_sum,
                "autoreply_count": autoreply_count,
                "pending_topups": pending_topups,
                "by_tariff": by_tariff,
            }

    def daily_report(self):
        """Admin uchun 'bugungi' oddiy hisobot: bugun ro'yxatdan o'tganlar,
        bugun ulanganlar (created_at sanasi bo'yicha, soat emas)."""
        with _lock:
            today = datetime.now().strftime("%Y-%m-%d")
            new_today = _conn.execute(
                "SELECT COUNT(*) c FROM users WHERE created_at LIKE ?", (f"{today}%",)
            ).fetchone()['c']
            active_contacts_today = _conn.execute(
                "SELECT COUNT(*) c FROM contacts WHERE last_seen LIKE ?", (f"{today}%",)
            ).fetchone()['c']
            return {"new_today": new_today, "active_contacts_today": active_contacts_today}

    # ------------------------------------------------------- 👥 mijozlar ---
    def upsert_contact(self, owner_id: int, chat_id: int, name: str):
        with _lock, _conn:
            now = datetime.now().isoformat()
            row = _conn.execute(
                "SELECT message_count FROM contacts WHERE owner_id = ? AND chat_id = ?",
                (owner_id, chat_id),
            ).fetchone()
            if row is None:
                _conn.execute(
                    "INSERT INTO contacts (owner_id, chat_id, name, message_count, "
                    "first_seen, last_seen) VALUES (?, ?, ?, 1, ?, ?)",
                    (owner_id, chat_id, name, now, now),
                )
            else:
                _conn.execute(
                    "UPDATE contacts SET name = ?, message_count = message_count + 1, "
                    "last_seen = ? WHERE owner_id = ? AND chat_id = ?",
                    (name, now, owner_id, chat_id),
                )

    def list_contacts(self, owner_id: int, limit: int = 20) -> List[sqlite3.Row]:
        with _lock:
            return _conn.execute(
                "SELECT * FROM contacts WHERE owner_id = ? ORDER BY last_seen DESC LIMIT ?",
                (owner_id, limit),
            ).fetchall()

    def get_contact(self, owner_id: int, chat_id: int):
        with _lock:
            return _conn.execute(
                "SELECT * FROM contacts WHERE owner_id = ? AND chat_id = ?",
                (owner_id, chat_id),
            ).fetchone()

    def set_contact_tag(self, owner_id: int, chat_id: int, tag: str):
        with _lock, _conn:
            _conn.execute(
                "UPDATE contacts SET tag = ? WHERE owner_id = ? AND chat_id = ?",
                (tag, owner_id, chat_id),
            )

    def set_contact_note(self, owner_id: int, chat_id: int, note: str):
        with _lock, _conn:
            _conn.execute(
                "UPDATE contacts SET note = ? WHERE owner_id = ? AND chat_id = ?",
                (note, owner_id, chat_id),
            )

    # ------------------------------------------------- 🔑 kalit so'zli javob --
    def add_keyword_reply(self, owner_id: int, keyword: str, reply_text: str) -> int:
        with _lock, _conn:
            cur = _conn.execute(
                "INSERT INTO keyword_replies (owner_id, keyword, reply_text) VALUES (?, ?, ?)",
                (owner_id, keyword.strip().lower(), reply_text.strip()),
            )
            return cur.lastrowid

    def list_keyword_replies(self, owner_id: int) -> List[sqlite3.Row]:
        with _lock:
            return _conn.execute(
                "SELECT * FROM keyword_replies WHERE owner_id = ? ORDER BY id",
                (owner_id,),
            ).fetchall()

    def delete_keyword_reply(self, owner_id: int, kw_id: int):
        with _lock, _conn:
            _conn.execute(
                "DELETE FROM keyword_replies WHERE owner_id = ? AND id = ?",
                (owner_id, kw_id),
            )

    def find_keyword_reply(self, owner_id: int, incoming_text: str) -> Optional[str]:
        """Kelgan xabar matnida (kichik harflarda) qaysidir kalit so'z
        uchrasa, mos javobni qaytaradi. Birinchi mos kelgani ishlatiladi."""
        if not incoming_text:
            return None
        low = incoming_text.lower()
        with _lock:
            rows = _conn.execute(
                "SELECT keyword, reply_text FROM keyword_replies WHERE owner_id = ? ORDER BY id",
                (owner_id,),
            ).fetchall()
        for r in rows:
            if r['keyword'] and r['keyword'] in low:
                return r['reply_text']
        return None

    # ------------------------------------------------------- 🧾 admin logi --
    def log_admin_action(self, action: str, target_id: Optional[int] = None, detail: str = ""):
        with _lock, _conn:
            _conn.execute(
                "INSERT INTO admin_logs (ts, action, target_id, detail) VALUES (?, ?, ?, ?)",
                (datetime.now().isoformat(), action, target_id, detail),
            )

    def list_admin_logs(self, limit: int = 20, offset: int = 0) -> List[sqlite3.Row]:
        with _lock:
            return _conn.execute(
                "SELECT * FROM admin_logs ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset)
            ).fetchall()

    # -------------------------------------------------- 🎨 premium emoji ---
    def set_premium_emoji(self, emoji_char: str, custom_emoji_id: str):
        with _lock, _conn:
            _conn.execute(
                "INSERT INTO premium_emoji_map (emoji_char, custom_emoji_id, updated_at) "
                "VALUES (?, ?, ?) ON CONFLICT(emoji_char) DO UPDATE SET "
                "custom_emoji_id = excluded.custom_emoji_id, updated_at = excluded.updated_at",
                (emoji_char, custom_emoji_id, datetime.now().isoformat()),
            )

    def remove_premium_emoji(self, emoji_char: str):
        with _lock, _conn:
            _conn.execute(
                "DELETE FROM premium_emoji_map WHERE emoji_char = ?", (emoji_char,)
            )

    def get_premium_emoji_map(self) -> dict:
        with _lock:
            rows = _conn.execute(
                "SELECT emoji_char, custom_emoji_id FROM premium_emoji_map"
            ).fetchall()
            return {r['emoji_char']: r['custom_emoji_id'] for r in rows}


storage = Storage()
